# Knxo Play

ዘመናዊ ቪዲዮ ማጫወቻ አፕ — Kotlin + Jetpack Compose + Media3 (ExoPlayer).

## መጀመር
1. Android Studio ክፈት → **Open** → ይህን ፎልደር ምረጥ
2. Gradle Sync እስኪጨርስ ጠብቅ
3. ስልክ ወይም emulator ላይ **Run**

## ባህሪያት
- Folders list፣ thumbnails፣ ቀጥሎ-መጫወት (continue) button
- Gestures፦ double-tap ±10s፣ የግራ swipe ብሩህነት፣ የቀኝ swipe ድምጽ
- Speed፣ rotate፣ lock፣ aspect ratio፣ PiP
- Music፦ Songs፣ Artists፣ Albums tabs፣ mini player፣ background playback

## ቀጣይ ስራዎች
- Subtitle (.srt) ድጋፍ
- Gesture ቁጥጥር (ብሩህነት፣ ድምጽ፣ double-tap seek)
- የፍጥነት ቁጥጥር፣ Picture-in-Picture፣ background play
