# Knxo Play

ዘመናዊ ቪዲዮ ማጫወቻ አፕ — Kotlin + Jetpack Compose + Media3 (ExoPlayer).

## መጀመር
1. Android Studio ክፈት → **Open** → ይህን ፎልደር ምረጥ
2. Gradle Sync እስኪጨርስ ጠብቅ
3. ስልክ ወይም emulator ላይ **Run**

## ቀጣይ ስራዎች
- Subtitle (.srt) ድጋፍ
- Gesture ቁጥጥር (ብሩህነት፣ ድምጽ፣ double-tap seek)
- የፍጥነት ቁጥጥር፣ Picture-in-Picture፣ background play
