plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example.myplayer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.myplayer"
        minSdk = 24
        targetSdk = 35
        versionCode = 20
        versionName = "7.2"
    }
    signingConfigs {
        create("knxo") {
            val pass = System.getenv("KNXO_SIGN_PASS")
            val ks = file("../signing/knxo-release.p12")
            if (!pass.isNullOrEmpty() && ks.exists()) {
                storeFile = ks
                storeType = "pkcs12"
                storePassword = pass
                keyAlias = "knxo"
                keyPassword = pass
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            val hasKey = !System.getenv("KNXO_SIGN_PASS").isNullOrEmpty() && file("../signing/knxo-release.p12").exists()
            signingConfig = if (hasKey) signingConfigs.getByName("knxo") else signingConfigs.getByName("debug")
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-video:2.7.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.5.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.5.1")
}
