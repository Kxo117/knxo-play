package com.example.myplayer

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

data class Video(
    val id: Long,
    val title: String,
    val durationMs: Long,
    val uri: Uri,
    val folder: String,
    val sizeBytes: Long,
    val mime: String = "video/*",
    val relPath: String = ""
)

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val uri: Uri,
    val fileName: String = "",
    val mime: String = "audio/*",
    val relPath: String = ""
)

fun albumArtUri(albumId: Long): Uri =
    android.content.ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)

fun loadVideos(context: Context): List<Video> {
    val list = mutableListOf<Video>()
    val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val cols = mutableListOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
        MediaStore.Video.Media.MIME_TYPE
    )
    if (Build.VERSION.SDK_INT >= 29) cols.add(MediaStore.MediaColumns.RELATIVE_PATH)
    context.contentResolver.query(
        base, cols.toTypedArray(), null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC"
    )?.use { c ->
        val id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val name = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        val dur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
        val size = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
        val bucket = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        val mime = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
        val rel = if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH) else -1
        while (c.moveToNext()) {
            val vid = c.getLong(id)
            list += Video(
                id = vid,
                title = c.getString(name) ?: "Video",
                durationMs = c.getLong(dur),
                uri = Uri.withAppendedPath(base, vid.toString()),
                folder = c.getString(bucket) ?: "Other",
                sizeBytes = c.getLong(size),
                mime = c.getString(mime) ?: "video/*",
                relPath = if (rel >= 0) (c.getString(rel) ?: "") else ""
            )
        }
    }
    return list
}

fun loadSongs(context: Context): List<Song> {
    val list = mutableListOf<Song>()
    val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val cols = mutableListOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DISPLAY_NAME,
        MediaStore.Audio.Media.MIME_TYPE
    )
    if (Build.VERSION.SDK_INT >= 29) cols.add(MediaStore.MediaColumns.RELATIVE_PATH)
    context.contentResolver.query(
        base, cols.toTypedArray(), "${MediaStore.Audio.Media.DURATION} > 10000", null,
        "${MediaStore.Audio.Media.DATE_ADDED} DESC"
    )?.use { c ->
        val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val albumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
        val dur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val fname = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
        val mime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
        val rel = if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH) else -1
        while (c.moveToNext()) {
            val sid = c.getLong(id)
            val a = c.getString(artist)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist"
            val al = c.getString(album)?.takeIf { it.isNotBlank() } ?: "Unknown album"
            list += Song(
                id = sid,
                title = c.getString(title) ?: "Song",
                artist = a,
                album = al,
                albumId = c.getLong(albumId),
                durationMs = c.getLong(dur),
                uri = Uri.withAppendedPath(base, sid.toString()),
                fileName = c.getString(fname) ?: "audio_$sid",
                mime = c.getString(mime) ?: "audio/*",
                relPath = if (rel >= 0) (c.getString(rel) ?: "") else ""
            )
        }
    }
    return list
}

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

fun formatSize(b: Long): String = when {
    b >= 1073741824L -> "%.1f GB".format(b / 1073741824.0)
    b >= 1048576L -> "%.1f MB".format(b / 1048576.0)
    else -> "${b / 1024} KB"
}

data class ResumeItem(val video: Video, val posMs: Long, val frac: Float)
