package com.example.myplayer

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

object Lang {
    var code by mutableStateOf("en")
}

fun loadLang(context: Context) {
    val i = Library(context).intPref("lang", -1)
    Lang.code = when (i) {
        1 -> "am"
        0 -> "en"
        else -> if (Locale.getDefault().language == "am") "am" else "en"
    }
}

fun tr(s: String): String = if (Lang.code == "am") (AmMap[s] ?: s) else s

private fun am() = Lang.code == "am"

fun trVideos(n: Int): String =
    if (am()) (if (n == 1) "1 ቪዲዮ" else "$n ቪዲዮዎች") else (if (n == 1) "1 video" else "$n videos")

fun trSongs(n: Int): String =
    if (am()) (if (n == 1) "1 ዘፈን" else "$n ዘፈኖች") else (if (n == 1) "1 song" else "$n songs")

fun trFolders(n: Int): String = if (am()) "$n አቃፊዎች" else "$n FOLDERS"
fun trSelected(n: Int): String = if (am()) "$n ተመርጠዋል" else "$n selected"
fun trMinutes(m: Int): String = if (am()) "$m ደቂቃ" else "$m minutes"
fun trVersion(v: String): String = if (am()) "ስሪት $v" else "Version $v"
fun trAddedTo(name: String): String = if (am()) "ወደ $name ተጨምሯል" else "Added to $name"
fun trSleepIn(m: Int): String = if (am()) "ከ$m ደቂቃ በኋላ ይቆማል" else "Sleep in $m min"
fun trBrightness(p: Int): String = if (am()) "ብሩህነት $p%" else "Brightness $p%"
fun trVolume(p: Int): String = if (am()) "ድምጽ $p%" else "Volume $p%"
fun trZoom(p: Int): String = if (am()) "ማጉላት $p%" else "Zoom $p%"
fun trCopied(done: Int, total: Int): String = if (am()) "$done ከ$total ተቀድቷል" else "$done of $total copied"
fun trRestored(f: Int, p: Int, miss: Int): String =
    if (am()) "$f ተወዳጆች እና $p ፕሌይሊስቶች ተመልሰዋል። $miss ንጥሎች በዚህ ስልክ ላይ አልተገኙም።"
    else "Restored $f favorites and $p playlists. $miss items were not found on this phone."

val AmMap: Map<String, String> = mapOf(
    "+ New folder" to "+ አዲስ አቃፊ",
    "+ New playlist" to "+ አዲስ ፕሌይሊስት",
    "Permission is needed to show your files" to "ፋይሎችን ለማየት ፈቃድ ያስፈልጋል",
    "A modern video and music player with gestures, subtitles, picture-in-picture and background music." to "በምልክቶች፣ በንዑስ ርዕስ፣ በፒክቸር-ኢን-ፒክቸር እና በጀርባ ሙዚቃ የተሞላ ዘመናዊ የቪዲዮ እና የሙዚቃ ማጫወቻ።",
    "A point set" to "ነጥብ A ተቀምጧል",
    "A-B loop off" to "A-B ድግግሞሽ ጠፍቷል",
    "A-B loop on" to "A-B ድግግሞሽ በርቷል",
    "AB Repeat" to "AB ድግግሞሽ",
    "AB on" to "AB በርቷል",
    "About" to "ስለ አፑ",
    "Add to favorites" to "ወደ ተወዳጆች ጨምር",
    "Add to playlist" to "ወደ ፕሌይሊስት ጨምር",
    "Albums" to "አልበሞች",
    "All videos" to "ሁሉም ቪዲዮዎች",
    "Allow access" to "መዳረሻ ፍቀድ",
    "Appearance" to "ውጫዊ ገጽታ",
    "Artists" to "ድምጻውያን",
    "Ascending" to "ወደ ላይ",
    "Aspect ratio" to "የምስል መጠን",
    "Audio only" to "ድምጽ ብቻ",
    "Back" to "ተመለስ",
    "Back 10 seconds" to "10 ሰከንድ ወደ ኋላ",
    "Back up" to "ምትኬ",
    "Back up favorites & playlists" to "ተወዳጆችን እና ፕሌይሊስቶችን ምትኬ አስቀምጥ",
    "Background Play" to "የጀርባ ማጫወት",
    "Backup" to "ምትኬ",
    "Backup saved" to "ምትኬው ተቀምጧል",
    "Built with open-source libraries: Android Media3 (ExoPlayer), Jetpack Compose and Coil." to "በክፍት-ምንጭ ቤተ-መጻሕፍት የተሰራ፦ Android Media3 (ExoPlayer)፣ Jetpack Compose እና Coil።",
    "Can't remove the last item" to "የመጨረሻውን ማስወገድ አይቻልም",
    "Cancel" to "ሰርዝ",
    "Channel" to "ቻናል",
    "Close" to "ዝጋ",
    "Continue" to "ቀጥል",
    "Continue watching" to "ማየት ቀጥል",
    "Copied, but the originals could not be removed" to "ተቀድቷል፣ ግን ዋናዎቹን ማስወገድ አልተቻለም",
    "Copy and move need Android 10 or newer" to "ቅዳ እና ውሰድ Android 10 ወይም ከዚያ በላይ ያስፈልጋቸዋል",
    "Copy to" to "ቅዳ ወደ",
    "Copy to…" to "ቅዳ ወደ…",
    "Could not prepare the app file" to "የአፑን ፋይል ማዘጋጀት አልተቻለም",
    "Could not prepare the backup" to "ምትኬውን ማዘጋጀት አልተቻለም",
    "Could not save the backup" to "ምትኬውን ማስቀመጥ አልተቻለም",
    "Could not start background play" to "የጀርባ ማጫወትን መጀመር አልተቻለም",
    "Create" to "ፍጠር",
    "Crop" to "ቁረጥ",
    "Date" to "ቀን",
    "Delete playlist" to "ፕሌይሊስቱን ሰርዝ",
    "Descending" to "ወደ ታች",
    "Developer" to "ገንቢ",
    "Done" to "ተጠናቋል",
    "End of song" to "ዘፈኑ ሲያልቅ",
    "End of this song" to "ይህ ዘፈን ሲያልቅ",
    "Enter a valid link starting with http, https or rtsp" to "በ http፣ https ወይም rtsp የሚጀምር ትክክለኛ ሊንክ ያስገቡ",
    "Equalizer" to "ኢኳላይዘር",
    "Favorite" to "ተወዳጅ",
    "Favorites" to "ተወዳጆች",
    "Favorites and playlists are saved by file name, so they can be restored even on a new phone." to "ተወዳጆች እና ፕሌይሊስቶች በፋይል ስም ስለሚቀመጡ በአዲስ ስልክ ላይም ሊመለሱ ይችላሉ።",
    "Fit" to "ተስማሚ",
    "Forward 10 seconds" to "10 ሰከንድ ወደ ፊት",
    "Grid" to "ፍርግርግ",
    "Grid columns" to "የፍርግርግ አምዶች",
    "Hide player controls after" to "የማጫወቻ ቁልፎችን ደብቅ ከ",
    "Keep screen on while playing" to "ሲጫወት ስክሪን አይጥፋ",
    "Knxo Play closed unexpectedly" to "Knxo Play ባልታሰበ ሁኔታ ተዘግቷል",
    "Landscape" to "አግድም",
    "Length" to "ርዝመት",
    "List" to "ዝርዝር",
    "Lock" to "ቆልፍ",
    "Longest first" to "ረጅሙ መጀመሪያ",
    "Loop" to "ድገም",
    "Loop all" to "ሁሉንም ድገም",
    "Loop one" to "አንዱን ድገም",
    "Menu" to "ምናሌ",
    "Mirror" to "መስታወት",
    "Mirror off" to "መስታወት ጠፍቷል",
    "Mirror on" to "መስታወት በርቷል",
    "More" to "ተጨማሪ",
    "Move needs Android 11 or newer. Use Copy instead." to "ውሰድ Android 11 ወይም ከዚያ በላይ ያስፈልገዋል። በምትኩ ቅዳ ይጠቀሙ።",
    "Move to" to "ውሰድ ወደ",
    "Move to…" to "ውሰድ ወደ…",
    "Music" to "ሙዚቃ",
    "Mute" to "ድምጽ አጥፋ",
    "Name" to "ስም",
    "Name A–Z" to "ስም ሀ–ፐ",
    "Name Z–A" to "ስም ፐ–ሀ",
    "Network stream" to "የኔትወርክ ስርጭት",
    "New folder" to "አዲስ አቃፊ",
    "New playlist" to "አዲስ ፕሌይሊስት",
    "Next" to "ቀጣይ",
    "Night Mode" to "የሌሊት ሁነታ",
    "Night mode off" to "የሌሊት ሁነታ ጠፍቷል",
    "Night mode on" to "የሌሊት ሁነታ በርቷል",
    "No equalizer found on this phone" to "በዚህ ስልክ ላይ ኢኳላይዘር አልተገኘም",
    "No favorites yet.\nUse ⋮ on any video or song, or long-press to select." to "እስካሁን ተወዳጅ የለም።\nበማንኛውም ቪዲዮ ወይም ዘፈን ላይ ⋮ ይጠቀሙ፣ ወይም ለመምረጥ በረጅሙ ይጫኑ።",
    "No system equalizer found on this phone" to "በዚህ ስልክ ላይ የሲስተም ኢኳላይዘር አልተገኘም",
    "Open" to "ክፈት",
    "Order" to "ቅደም ተከተል",
    "Pick a Knxo Play backup file" to "የ Knxo Play ምትኬ ፋይል ይምረጡ",
    "Pick a later point for B" to "ለ B ዘግይቶ ያለ ነጥብ ይምረጡ",
    "Picture-in-picture when leaving" to "ስወጣ ፒክቸር-ኢን-ፒክቸር",
    "Play" to "አጫውት",
    "Play all" to "ሁሉንም አጫውት",
    "Playback" to "ማጫወት",
    "Playlist" to "ፕሌይሊስት",
    "Playlists" to "ፕሌይሊስቶች",
    "Please share this report with the developer so the problem can be fixed." to "ችግሩ እንዲስተካከል እባክዎ ይህን ሪፖርት ለገንቢው ያጋሩ።",
    "Pop-up Play" to "ብቅ-ባይ ማጫወት",
    "Previous" to "ቀዳሚ",
    "Queue" to "ወረፋ",
    "Recent" to "በቅርቡ",
    "Refresh" to "አድስ",
    "Remove" to "አስወግድ",
    "Remove from favorites" to "ከተወዳጆች አስወግድ",
    "Remove from playlist" to "ከፕሌይሊስት አስወግድ",
    "Repeat" to "ድገም",
    "Reset zoom" to "ማጉላትን መልስ",
    "Restore from backup" to "ከምትኬ መልስ",
    "Save to a file" to "በፋይል አስቀምጥ",
    "Save to a file or send it" to "በፋይል አስቀምጥ ወይም ላክ",
    "Screenshot" to "ስክሪንሾት",
    "Screenshot failed" to "ስክሪንሾት አልተሳካም",
    "Screenshot saved to Pictures/KnxoPlay" to "ስክሪንሾት በ Pictures/KnxoPlay ተቀምጧል",
    "Search" to "ፈልግ",
    "Select only videos or only songs" to "ቪዲዮዎችን ብቻ ወይም ዘፈኖችን ብቻ ይምረጡ",
    "Send (Telegram, Drive, ...)" to "ላክ (Telegram፣ Drive፣ ...)",
    "Send Knxo Play to a friend" to "Knxo Play ን ለጓደኛ ላክ",
    "Send app file (APK)" to "የአፑን ፋይል (APK) ላክ",
    "Send invite message" to "የግብዣ መልእክት ላክ",
    "Set B" to "B አስቀምጥ",
    "Settings" to "ቅንብሮች",
    "Share" to "አጋራ",
    "Share report" to "ሪፖርቱን አጋራ",
    "Share this app" to "ይህን አፕ አጋራ",
    "Shortest first" to "አጭሩ መጀመሪያ",
    "Show duration" to "ርዝመት አሳይ",
    "Show file size" to "የፋይል መጠን አሳይ",
    "Shuffle" to "ቀላቅል",
    "Shuffle off" to "ቅልቅል ጠፍቷል",
    "Shuffle on" to "ቅልቅል በርቷል",
    "Shuffle: off" to "ቅልቅል፦ ጠፍቷል",
    "Shuffle: on" to "ቅልቅል፦ በርቷል",
    "Size" to "መጠን",
    "Sleep" to "እንቅልፍ",
    "Sleep on" to "እንቅልፍ በርቷል",
    "Sleep timer" to "የእንቅልፍ ሰዓት ቆጣሪ",
    "Sleep timer off" to "የእንቅልፍ ሰዓት ቆጣሪ ጠፍቷል",
    "Sleep timer: stopped" to "የእንቅልፍ ሰዓት ቆጣሪ፦ ቆሟል",
    "Songs" to "ዘፈኖች",
    "Sort by" to "ደርድር በ",
    "Speed" to "ፍጥነት",
    "Stream" to "ስርጭት",
    "Stream URL (http, https, rtsp)" to "የስርጭት ሊንክ (http፣ https፣ rtsp)",
    "Stretch" to "ዘርጋ",
    "Subtitle added" to "ንዑስ ርዕስ ተጨምሯል",
    "Subtitles" to "ንዑስ ርዕሶች",
    "Thank you" to "እናመሰግናለን",
    "Thank you for using Knxo Play. Your support and feedback help it grow." to "Knxo Play ን ስለተጠቀሙ እናመሰግናለን። ድጋፍዎ እና አስተያየትዎ እንዲያድግ ይረዳሉ።",
    "Theme" to "ገጽታ",
    "This is not a valid Knxo Play backup file" to "ይህ ትክክለኛ የ Knxo Play ምትኬ ፋይል አይደለም",
    "Turn off" to "አጥፋ",
    "Turn off timer" to "ሰዓት ቆጣሪውን አጥፋ",
    "Unlock" to "ክፈት",
    "Unmute" to "ድምጽ አብራ",
    "Use" to "ተጠቀም",
    "Video" to "ቪዲዮ",
    "Video on" to "ቪዲዮ በርቷል",
    "Videos" to "ቪዲዮዎች",
    "View & sort" to "እይታ እና ደርድር",
    "View mode" to "የእይታ ሁነታ",
    "Working…" to "በመስራት ላይ…",
    "Language" to "ቋንቋ",
    "Lyrics" to "ግጥም",
    "No lyrics yet" to "እስካሁን ግጥም የለም",
    "Paste lyrics" to "ግጥም ለጥፍ",
    "Open lyrics file (.lrc or .txt)" to "የግጥም ፋይል ክፈት (.lrc ወይም .txt)",
    "Edit" to "አርም",
    "Save" to "አስቀምጥ",
    "Remove lyrics" to "ግጥም አስወግድ",
    "Could not read the file" to "ፋይሉን ማንበብ አልተቻለም",
    "Light" to "ብርሃን",
    "Dark gray" to "ጥቁር ግራጫ",
    "Black" to "ጥቁር",
    "Purple" to "ሐምራዊ",
    "Green" to "አረንጓዴ",
    "Crimson" to "ደማቅ ቀይ",
    "Violet" to "ወይን ጠጅ",
    "Ocean" to "ውቅያኖስ",
    "Blue" to "ሰማያዊ"
)
