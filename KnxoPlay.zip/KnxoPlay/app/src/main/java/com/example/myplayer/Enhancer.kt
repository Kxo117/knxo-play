package com.example.myplayer

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix

class EnhancerPreset(val name: String, val matrix: FloatArray?)

private fun makeMatrix(c: Float, bri: Float, sat: Float, r: Float, g: Float, b: Float): FloatArray {
    val lr = 0.213f
    val lg = 0.715f
    val lb = 0.072f
    val s = sat
    val off = 128f * (1f - c) + bri
    return floatArrayOf(
        r * c * (lr * (1 - s) + s), r * c * (lg * (1 - s)), r * c * (lb * (1 - s)), 0f, r * off,
        g * c * (lr * (1 - s)), g * c * (lg * (1 - s) + s), g * c * (lb * (1 - s)), 0f, g * off,
        b * c * (lr * (1 - s)), b * c * (lg * (1 - s)), b * c * (lb * (1 - s) + s), 0f, b * off,
        0f, 0f, 0f, 1f, 0f
    )
}

val EnhancerPresets: List<EnhancerPreset> = listOf(
    EnhancerPreset("Original", null),
    EnhancerPreset("HDR", makeMatrix(1.20f, 8f, 1.40f, 1f, 1f, 1f)),
    EnhancerPreset("Clear", makeMatrix(1.08f, 0f, 1.12f, 1f, 1f, 1f)),
    EnhancerPreset("Ultra Clear", makeMatrix(1.18f, -4f, 1.28f, 1f, 1f, 1f)),
    EnhancerPreset("Arctic Blue", makeMatrix(1.08f, 0f, 1.05f, 0.88f, 1f, 1.15f)),
    EnhancerPreset("Warm Glow", makeMatrix(1.06f, 3f, 1.10f, 1.12f, 1.02f, 0.86f)),
    EnhancerPreset("Cinematic", makeMatrix(1.20f, -6f, 0.88f, 1.06f, 1f, 0.94f))
)

@Composable
private fun PresetCard(
    p: EnhancerPreset,
    selected: Boolean,
    previewUri: Uri?,
    loader: ImageLoader,
    onClick: () -> Unit,
    modifier: Modifier
) {
    val context = LocalContext.current
    val m = p.matrix
    Box(
        modifier
            .aspectRatio(1.5f)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF2A2A2E))
            .border(2.dp, if (selected) Color.White else Color.Transparent, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        if (m == null) {
            Icon(Icons.Filled.Block, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(40.dp))
        } else if (previewUri != null) {
            AsyncImage(
                model = remember(previewUri) { ImageRequest.Builder(context).data(previewUri).videoFrameMillis(2000).build() },
                imageLoader = loader,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                colorFilter = ColorFilter.colorMatrix(ComposeColorMatrix(m)),
                modifier = Modifier.fillMaxSize()
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(40.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000))))
        )
        Text(
            tr(p.name),
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
        )
    }
}

@Composable
fun EnhancerPanel(
    current: Int,
    previewUri: Uri?,
    loader: ImageLoader,
    onPick: (Int) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rows = (EnhancerPresets.size + 1) / 2
    Column(
        modifier
            .fillMaxHeight()
            .widthIn(max = 340.dp)
            .fillMaxWidth(0.92f)
            .background(Color(0xEE0B0F18))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Close"), tint = Color.White)
            }
            Text(tr("Visual Enhancer"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(rows) { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (k in 0..1) {
                        val idx = r * 2 + k
                        if (idx < EnhancerPresets.size) {
                            PresetCard(
                                EnhancerPresets[idx], idx == current, previewUri, loader,
                                { onPick(idx) }, Modifier.weight(1f)
                            )
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
