package com.example.myplayer

import android.app.Application
import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter

class KnxoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                getSharedPreferences("knxo_crash", Context.MODE_PRIVATE)
                    .edit()
                    .putString("trace", "Thread: ${thread.name}\n" + sw.toString().take(6000))
                    .commit()
            } catch (t: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }
}
