package com.example.myplayer

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@androidx.annotation.OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private var inPip by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val uris = intent.getStringArrayListExtra("uris") ?: arrayListOf()
        val titles = intent.getStringArrayListExtra("titles") ?: arrayListOf()
        val start = intent.getIntExtra("index", 0)
        val pos = intent.getLongExtra("pos", 0L)

        player = ExoPlayer.Builder(this).build().apply {
            setMediaItems(
                uris.mapIndexed { i, u ->
                    MediaItem.Builder()
                        .setUri(u)
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(titles.getOrNull(i)).build())
                        .build()
                },
                start,
                pos
            )
            prepare()
            playWhenReady = true
        }

        setContent {
            KnxoTheme {
                PlayerScreen(
                    exo = player,
                    inPip = inPip,
                    onBack = { finish() },
                    onPip = { enterPip() },
                    onRotate = {
                        requestedOrientation =
                            if (requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    }
                )
            }
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().build())
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player.isPlaying) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    override fun onStop() {
        super.onStop()
        val item = player.currentMediaItem
        val uri = item?.localConfiguration?.uri?.toString()
        if (uri != null) {
            getSharedPreferences("knxo", Context.MODE_PRIVATE).edit()
                .putString("uri", uri)
                .putString("title", item.mediaMetadata.title?.toString() ?: "")
                .putLong("pos", player.currentPosition)
                .apply()
        }
        player.pause()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

private val speeds = listOf(0.5f, 1f, 1.25f, 1.5f, 2f)
private val resizeModes = listOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT,
    AspectRatioFrameLayout.RESIZE_MODE_FILL,
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM
)
private val resizeNames = listOf("Fit", "Stretch", "Crop")

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    exo: ExoPlayer,
    inPip: Boolean,
    onBack: () -> Unit,
    onPip: () -> Unit,
    onRotate: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as Activity
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }

    var playing by remember { mutableStateOf(exo.isPlaying) }
    var title by remember { mutableStateOf(exo.mediaMetadata.title?.toString() ?: "") }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var showControls by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var speedIndex by remember { mutableIntStateOf(1) }
    var resizeIndex by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf<String?>(null) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var brightness by remember {
        mutableFloatStateOf(activity.window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it })
    }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                title = mediaItem?.mediaMetadata?.title?.toString() ?: ""
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }

    LaunchedEffect(exo) {
        while (true) {
            if (!dragging) {
                position = exo.currentPosition.coerceAtLeast(0L)
                duration = exo.duration.coerceAtLeast(0L)
            }
            delay(250)
        }
    }
    LaunchedEffect(showControls, playing, dragging) {
        if (showControls && playing && !dragging) {
            delay(3500)
            showControls = false
        }
    }
    LaunchedEffect(hint) {
        if (hint != null) {
            delay(900)
            hint = null
        }
    }

    fun seekBy(ms: Long) {
        val target = (exo.currentPosition + ms).coerceIn(0L, exo.duration.coerceAtLeast(0L))
        exo.seekTo(target)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(locked) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { offset ->
                        if (!locked) {
                            if (offset.x < size.width / 2f) {
                                seekBy(-10_000)
                                hint = "⏪ 10s"
                            } else {
                                seekBy(10_000)
                                hint = "10s ⏩"
                            }
                        }
                    }
                )
            }
            .pointerInput(locked) {
                if (!locked) {
                    detectVerticalDragGestures { change, dragAmount ->
                        val delta = -dragAmount / size.height * 1.3f
                        if (change.position.x < size.width / 2f) {
                            brightness = (brightness + delta).coerceIn(0.02f, 1f)
                            val lp = activity.window.attributes
                            lp.screenBrightness = brightness
                            activity.window.attributes = lp
                            hint = "Brightness ${(brightness * 100).roundToInt()}%"
                        } else {
                            volume = (volume + delta).coerceIn(0f, 1f)
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (volume * maxVol).roundToInt(), 0)
                            hint = "Volume ${(volume * 100).roundToInt()}%"
                        }
                    }
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    this.player = exo
                }
            },
            update = { it.resizeMode = resizeModes[resizeIndex] }
        )

        hint?.let {
            Text(
                it,
                color = Color.White,
                fontSize = 18.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0x99000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            )
        }

        if (!inPip) {
            AnimatedVisibility(
                visible = showControls && !locked,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier
                            .align(Alignment.TopStart)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent)))
                            .statusBarsPadding()
                            .padding(bottom = 16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                            Text(title, color = Color.White, fontSize = 16.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        }
                        Row(
                            Modifier.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            val s = speeds[speedIndex]
                            Text(
                                if (s % 1f == 0f) "${s.toInt()}x" else "${s}x",
                                color = Color.White,
                                fontSize = 15.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0x55FFFFFF))
                                    .clickable {
                                        speedIndex = (speedIndex + 1) % speeds.size
                                        exo.setPlaybackSpeed(speeds[speedIndex])
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                            IconButton(onClick = onRotate) { Icon(Icons.Filled.ScreenRotation, "Rotate", tint = Color.White) }
                        }
                    }

                    Column(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000))))
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(formatDuration(position), color = Color.White, fontSize = 13.sp)
                            Slider(
                                value = position.toFloat(),
                                onValueChange = { dragging = true; position = it.toLong() },
                                onValueChangeFinished = { exo.seekTo(position); dragging = false },
                                valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                            )
                            Text(formatDuration(duration), color = Color.White, fontSize = 13.sp)
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { locked = true; showControls = false }) {
                                Icon(Icons.Filled.Lock, "Lock", tint = Color.White)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { exo.seekToPreviousMediaItem() }) {
                                    Icon(Icons.Filled.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(32.dp))
                                }
                                IconButton(
                                    onClick = { if (exo.isPlaying) exo.pause() else exo.play() },
                                    modifier = Modifier.size(64.dp)
                                ) {
                                    Icon(
                                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        "Play/Pause",
                                        tint = Color.White,
                                        modifier = Modifier.size(48.dp)
                                    )
                                }
                                IconButton(onClick = { exo.seekToNextMediaItem() }) {
                                    Icon(Icons.Filled.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(32.dp))
                                }
                            }
                            Row {
                                IconButton(onClick = {
                                    resizeIndex = (resizeIndex + 1) % resizeModes.size
                                    hint = resizeNames[resizeIndex]
                                }) { Icon(Icons.Filled.AspectRatio, "Aspect ratio", tint = Color.White) }
                                IconButton(onClick = onPip) {
                                    Icon(Icons.Filled.PictureInPictureAlt, "Picture in picture", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(visible = showControls && locked, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize()) {
                    IconButton(
                        onClick = { locked = false; showControls = true },
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(16.dp)
                            .background(Color(0x66000000), CircleShape)
                    ) { Icon(Icons.Filled.LockOpen, "Unlock", tint = Color.White) }
                }
            }
        }
    }
}
