package com.example.myplayer

import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.core.content.ContextCompat
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@androidx.annotation.OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private var inPip by mutableStateOf(false)

    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) applySubtitle(uri)
    }

    private fun applySubtitle(uri: Uri) {
        val item = player.currentMediaItem ?: return
        var name = ""
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: ""
        }
        val lower = name.lowercase()
        val mime = when {
            lower.endsWith(".vtt") -> "text/vtt"
            lower.endsWith(".ass") || lower.endsWith(".ssa") -> "text/x-ssa"
            else -> "application/x-subrip"
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        player.replaceMediaItem(idx, item.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(idx, pos)
        Toast.makeText(this, "Subtitle added", Toast.LENGTH_SHORT).show()
    }

    private fun playInBackground() {
        val items = (0 until player.mediaItemCount).map { i ->
            val mi = player.getMediaItemAt(i)
            mi.buildUpon().setMediaId(mi.localConfiguration?.uri?.toString() ?: "item$i").build()
        }
        if (items.isEmpty()) return
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        player.pause()
        val app = applicationContext
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            try {
                val c = f.get()
                c.setMediaItems(items, idx, pos)
                c.prepare()
                c.play()
            } catch (e: Exception) {
                Toast.makeText(this, "Could not start background play", Toast.LENGTH_SHORT).show()
            }
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    MediaController.releaseFuture(f)
                } catch (e: Exception) {
                }
            }, 2000)
            finish()
        }, ContextCompat.getMainExecutor(app))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadTheme(this)
        if (Library(this).flag("keep_on", true)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val uris = intent.getStringArrayListExtra("uris") ?: arrayListOf()
        val titles = intent.getStringArrayListExtra("titles") ?: arrayListOf()
        val start = intent.getIntExtra("index", 0)
        val pos = intent.getLongExtra("pos", 0L)

        player = ExoPlayer.Builder(this).setAudioAttributes(AudioAttributes.DEFAULT, true).build().apply {
            setMediaItems(
                uris.mapIndexed { i, u ->
                    MediaItem.Builder()
                        .setUri(u)
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(titles.getOrNull(i)).build())
                        .build()
                },
                start,
                pos
            )
            prepare()
            playWhenReady = true
        }

        val lib = Library(this)
        fun noteRecent() {
            val u = player.currentMediaItem?.localConfiguration?.uri?.toString()
            if (u != null && u.startsWith("content://")) lib.addRecent(u)
        }
        noteRecent()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                noteRecent()
            }
        })

        val durs = intent.getLongArrayExtra("durs")
        val durMap: Map<String, Long> = uris.indices.associate { uris[it] to (durs?.getOrNull(it) ?: 0L) }

        setContent {
            KnxoTheme {
                PlayerScreen(
                    exo = player,
                    inPip = inPip,
                    onBack = { finish() },
                    onPip = { enterPip() },
                    durations = durMap,
                    onBackground = { playInBackground() },
                    onSubtitle = { pickSubtitle.launch(arrayOf("*/*")) },
                    onRotate = {
                        requestedOrientation =
                            if (requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    }
                )
            }
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().build())
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player.isPlaying && Library(this).flag("auto_pip", true)) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    override fun onStop() {
        super.onStop()
        val item = player.currentMediaItem
        val uri = item?.localConfiguration?.uri?.toString()
        if (uri != null) {
            getSharedPreferences("knxo", Context.MODE_PRIVATE).edit()
                .putString("uri", uri)
                .putString("title", item.mediaMetadata.title?.toString() ?: "")
                .putLong("pos", player.currentPosition)
                .apply()
            Library(this).savePos(uri, player.currentPosition)
        }
        player.pause()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

private val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
private val resizeModes = listOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT,
    AspectRatioFrameLayout.RESIZE_MODE_FILL,
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM
)
private val resizeNames = listOf("Fit", "Stretch", "Crop")

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    exo: ExoPlayer,
    inPip: Boolean,
    onBack: () -> Unit,
    onPip: () -> Unit,
    onRotate: () -> Unit,
    onSubtitle: () -> Unit,
    durations: Map<String, Long>,
    onBackground: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as Activity
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }

    var playing by remember { mutableStateOf(exo.isPlaying) }
    var title by remember { mutableStateOf(exo.mediaMetadata.title?.toString() ?: "") }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var showControls by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var speedIndex by remember { mutableIntStateOf(2) }
    var night by remember { mutableStateOf(false) }
    var shuffleOn by remember { mutableStateOf(exo.shuffleModeEnabled) }
    var repeatMode by remember { mutableIntStateOf(exo.repeatMode) }
    var muted by remember { mutableStateOf(false) }
    var audioOnly by remember { mutableStateOf(false) }
    var mirror by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var showQueue by remember { mutableStateOf(false) }
    var touchTick by remember { mutableIntStateOf(0) }
    val hideMs = remember { Library(context).intPref("hide_secs", 8) * 1000L }
    var queueVersion by remember { mutableIntStateOf(0) }
    var curIndex by remember { mutableIntStateOf(exo.currentMediaItemIndex) }
    val thumbLoader = remember { ImageLoader.Builder(context).components { add(VideoFrameDecoder.Factory()) }.build() }
    var sleepUntil by remember { mutableLongStateOf(0L) }
    var showSleep by remember { mutableStateOf(false) }
    var abState by remember { mutableIntStateOf(0) }
    var abA by remember { mutableLongStateOf(0L) }
    var abB by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()
    var resizeIndex by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf<String?>(null) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var brightness by remember {
        mutableFloatStateOf(activity.window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it })
    }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                title = mediaItem?.mediaMetadata?.title?.toString() ?: ""
                curIndex = exo.currentMediaItemIndex
            }
            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                queueVersion++
                curIndex = exo.currentMediaItemIndex
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }

    LaunchedEffect(exo) {
        while (true) {
            if (!dragging) {
                position = exo.currentPosition.coerceAtLeast(0L)
                duration = exo.duration.coerceAtLeast(0L)
            }
            delay(250)
        }
    }
    LaunchedEffect(showControls, playing, dragging, touchTick, showQueue, showSleep) {
        if (showControls && playing && !dragging && !showQueue && !showSleep) {
            delay(hideMs)
            showControls = false
        }
    }
    LaunchedEffect(hint) {
        if (hint != null) {
            delay(900)
            hint = null
        }
    }

    LaunchedEffect(sleepUntil) {
        if (sleepUntil > 0L) {
            delay((sleepUntil - System.currentTimeMillis()).coerceAtLeast(0L))
            exo.pause()
            sleepUntil = 0L
            hint = "Sleep timer: stopped"
        }
    }
    LaunchedEffect(abState, abA, abB) {
        if (abState == 2) {
            while (true) {
                if (exo.currentPosition >= abB) exo.seekTo(abA)
                delay(100)
            }
        }
    }

    fun takeScreenshot() {
        val uri = exo.currentMediaItem?.localConfiguration?.uri ?: return
        val pos = exo.currentPosition
        scope.launch {
            val ok = withContext(Dispatchers.IO) { saveFrame(context, uri, pos) }
            hint = if (ok) "Screenshot saved to Pictures/KnxoPlay" else "Screenshot failed"
        }
    }

    fun seekBy(ms: Long) {
        val target = (exo.currentPosition + ms).coerceIn(0L, exo.duration.coerceAtLeast(0L))
        exo.seekTo(target)
    }

    val qItems = remember(queueVersion) {
        (0 until exo.mediaItemCount).map { i ->
            val mi = exo.getMediaItemAt(i)
            val u = mi.localConfiguration?.uri?.toString() ?: ""
            QItem(u, mi.mediaMetadata.title?.toString() ?: u.substringAfterLast('/'), durations[u] ?: 0L)
        }
    }

    fun openEq() {
        val i = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
            .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, exo.audioSessionId)
            .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
            .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MOVIE)
        try {
            context.startActivity(i)
        } catch (e: Exception) {
            hint = "No equalizer found on this phone"
        }
    }

    fun reorder(sorted: List<QItem>) {
        sorted.forEachIndexed { target, q ->
            var cur = -1
            for (i in 0 until exo.mediaItemCount) {
                if (exo.getMediaItemAt(i).localConfiguration?.uri?.toString() == q.uri) {
                    cur = i
                    break
                }
            }
            if (cur >= 0 && cur != target) exo.moveMediaItem(cur, target)
        }
        queueVersion++
        curIndex = exo.currentMediaItemIndex
    }

    fun applyOrder(kind: String) {
        when (kind) {
            "az" -> reorder(qItems.sortedBy { it.title.lowercase() })
            "za" -> reorder(qItems.sortedByDescending { it.title.lowercase() })
            "short" -> reorder(qItems.sortedBy { it.dur })
            "long" -> reorder(qItems.sortedByDescending { it.dur })
            else -> {
                shuffleOn = !shuffleOn
                exo.shuffleModeEnabled = shuffleOn
                hint = if (shuffleOn) "Shuffle on" else "Shuffle off"
            }
        }
    }

    BackHandler(enabled = showQueue) { showQueue = false }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitPointerEvent(PointerEventPass.Initial)
                        touchTick++
                    }
                }
            }
            .pointerInput(locked) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { offset ->
                        if (!locked) {
                            if (offset.x < size.width / 2f) {
                                seekBy(-10_000)
                                hint = "⏪ 10s"
                            } else {
                                seekBy(10_000)
                                hint = "10s ⏩"
                            }
                        }
                    }
                )
            }
            .pointerInput(locked) {
                if (!locked) {
                    detectVerticalDragGestures { change, dragAmount ->
                        val delta = -dragAmount / size.height * 1.3f
                        if (change.position.x < size.width / 2f) {
                            brightness = (brightness + delta).coerceIn(0.02f, 1f)
                            val lp = activity.window.attributes
                            lp.screenBrightness = brightness
                            activity.window.attributes = lp
                            hint = "Brightness ${(brightness * 100).roundToInt()}%"
                        } else {
                            volume = (volume + delta).coerceIn(0f, 1f)
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (volume * maxVol).roundToInt(), 0)
                            hint = "Volume ${(volume * 100).roundToInt()}%"
                        }
                    }
                }
            }
            .pointerInput(locked) {
                if (!locked) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        var lastDist = 0f
                        var lastCenter = Offset.Zero
                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.size >= 2) {
                                val a = pressed[0].position
                                val b = pressed[1].position
                                val dist = (a - b).getDistance()
                                val center = (a + b) / 2f
                                if (lastDist > 0f) {
                                    zoom = (zoom * (dist / lastDist)).coerceIn(1f, 5f)
                                    val maxX = size.width * (zoom - 1f) / 2f
                                    val maxY = size.height * (zoom - 1f) / 2f
                                    panX = (panX + center.x - lastCenter.x).coerceIn(-maxX, maxX)
                                    panY = (panY + center.y - lastCenter.y).coerceIn(-maxY, maxY)
                                    hint = "Zoom ${(zoom * 100).roundToInt()}%"
                                }
                                lastDist = dist
                                lastCenter = center
                                event.changes.forEach { it.consume() }
                            } else {
                                lastDist = 0f
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    this.player = exo
                }
            },
            update = {
                it.resizeMode = resizeModes[resizeIndex]
                it.scaleX = zoom * (if (mirror) -1f else 1f)
                it.scaleY = zoom
                it.translationX = panX
                it.translationY = panY
            }
        )

        if (audioOnly) {
            Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.MusicNote, null, tint = Grey, modifier = Modifier.size(96.dp))
            }
        }

        if (night) {
            Box(Modifier.fillMaxSize().background(Color(0x66402000)))
        }

        if (showSleep) {
            AlertDialog(
                onDismissRequest = { showSleep = false },
                containerColor = CardColor,
                title = { Text("Sleep timer") },
                text = {
                    Column {
                        listOf(15, 30, 45, 60, 90).forEach { m ->
                            Text(
                                "$m minutes",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        sleepUntil = System.currentTimeMillis() + m * 60_000L
                                        showSleep = false
                                        hint = "Sleep in $m min"
                                    }
                                    .padding(vertical = 12.dp)
                            )
                        }
                        if (sleepUntil > 0L) {
                            Text(
                                "Turn off",
                                color = Blue,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        sleepUntil = 0L
                                        showSleep = false
                                        hint = "Sleep timer off"
                                    }
                                    .padding(vertical = 12.dp)
                            )
                        }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { showSleep = false }) { Text("Cancel") } }
            )
        }

        hint?.let {
            Text(
                it,
                color = Color.White,
                fontSize = 18.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0x99000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            )
        }

        if (!inPip) {
            AnimatedVisibility(
                visible = showControls && !locked,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier
                            .align(Alignment.TopStart)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent)))
                            .statusBarsPadding()
                            .padding(bottom = 16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                            Text(title, color = Color.White, fontSize = 16.sp, maxLines = 1, modifier = Modifier.weight(1f))
                            IconButton(onClick = { showQueue = true }) {
                                Icon(Icons.Filled.QueueMusic, "Queue", tint = Color.White)
                            }
                        }
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            ToolButton("Night Mode", night, Icons.Filled.NightsStay) {
                                night = !night
                                hint = if (night) "Night mode on" else "Night mode off"
                            }
                            ToolButton(
                                when (abState) {
                                    0 -> "AB Repeat"
                                    1 -> "Set B"
                                    else -> "AB on"
                                },
                                abState != 0,
                                Icons.Filled.Loop
                            ) {
                                if (abState == 0) {
                                    abA = exo.currentPosition
                                    abState = 1
                                    hint = "A point set"
                                } else if (abState == 1) {
                                    if (exo.currentPosition > abA + 500) {
                                        abB = exo.currentPosition
                                        abState = 2
                                        hint = "A-B loop on"
                                    } else {
                                        hint = "Pick a later point for B"
                                    }
                                } else {
                                    abState = 0
                                    hint = "A-B loop off"
                                }
                            }
                            ToolButton("Pop-up Play", false, Icons.Filled.PictureInPictureAlt) { onPip() }
                            ToolButton("Equalizer", false, Icons.Filled.Tune) { openEq() }
                            ToolButton("Mirror", mirror, Icons.Filled.Flip) {
                                mirror = !mirror
                                hint = if (mirror) "Mirror on" else "Mirror off"
                            }
                            if (zoom != 1f) {
                                ToolButton("Reset zoom", true, Icons.Filled.ZoomOutMap) {
                                    zoom = 1f
                                    panX = 0f
                                    panY = 0f
                                }
                            }
                            ToolButton("Landscape", false, Icons.Filled.ScreenRotation) { onRotate() }
                            ToolButton(
                                if (muted) "Unmute" else "Mute",
                                muted,
                                if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp
                            ) {
                                muted = !muted
                                exo.volume = if (muted) 0f else 1f
                            }
                            ToolButton("Background Play", false, Icons.Filled.Headphones) { onBackground() }
                            ToolButton("Speed", speedIndex != 2, text = "${speeds[speedIndex]}x") {
                                speedIndex = (speedIndex + 1) % speeds.size
                                exo.setPlaybackSpeed(speeds[speedIndex])
                            }
                            ToolButton(
                                when (repeatMode) {
                                    Player.REPEAT_MODE_ONE -> "Loop one"
                                    Player.REPEAT_MODE_ALL -> "Loop all"
                                    else -> "Loop"
                                },
                                repeatMode != Player.REPEAT_MODE_OFF,
                                if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat
                            ) {
                                repeatMode = when (repeatMode) {
                                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
                                    Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
                                    else -> Player.REPEAT_MODE_OFF
                                }
                                exo.repeatMode = repeatMode
                            }
                            ToolButton("Shuffle", shuffleOn, Icons.Filled.Shuffle) {
                                shuffleOn = !shuffleOn
                                exo.shuffleModeEnabled = shuffleOn
                                hint = if (shuffleOn) "Shuffle on" else "Shuffle off"
                            }
                            ToolButton(if (sleepUntil > 0L) "Sleep on" else "Sleep", sleepUntil > 0L, Icons.Filled.Timer) {
                                showSleep = true
                            }
                            ToolButton("Audio only", audioOnly, Icons.Filled.MusicNote) {
                                audioOnly = !audioOnly
                                exo.trackSelectionParameters = exo.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly)
                                    .build()
                                hint = if (audioOnly) "Audio only" else "Video on"
                            }
                            ToolButton("Screenshot", false, Icons.Filled.PhotoCamera) { takeScreenshot() }
                            ToolButton("Subtitles", false, Icons.Filled.ClosedCaption) { onSubtitle() }
                            ToolButton("Share", false, Icons.Filled.Share) {
                                exo.currentMediaItem?.localConfiguration?.uri?.let { context.shareMedia(it, "video/*") }
                            }
                        }
                    }

                    IconButton(
                        onClick = { takeScreenshot() },
                        modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
                    ) { Icon(Icons.Filled.PhotoCamera, "Screenshot", tint = Color.White) }

                    Column(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000))))
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(formatDuration(position), color = Color.White, fontSize = 13.sp)
                            Slider(
                                value = position.toFloat(),
                                onValueChange = { dragging = true; position = it.toLong() },
                                onValueChangeFinished = { exo.seekTo(position); dragging = false },
                                valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                            )
                            Text(formatDuration(duration), color = Color.White, fontSize = 13.sp)
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { locked = true; showControls = false }) {
                                Icon(Icons.Filled.Lock, "Lock", tint = Color.White)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { seekBy(-10_000); hint = "⏪ 10s" },
                                    modifier = Modifier.size(44.dp)
                                ) { Icon(Icons.Filled.Replay10, "Back 10 seconds", tint = Color.White, modifier = Modifier.size(28.dp)) }
                                IconButton(
                                    onClick = { exo.seekToPreviousMediaItem() },
                                    modifier = Modifier.size(44.dp)
                                ) { Icon(Icons.Filled.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(28.dp)) }
                                IconButton(
                                    onClick = { if (exo.isPlaying) exo.pause() else exo.play() },
                                    modifier = Modifier.size(60.dp)
                                ) {
                                    Icon(
                                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        "Play/Pause",
                                        tint = Color.White,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { exo.seekToNextMediaItem() },
                                    modifier = Modifier.size(44.dp)
                                ) { Icon(Icons.Filled.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(28.dp)) }
                                IconButton(
                                    onClick = { seekBy(10_000); hint = "10s ⏩" },
                                    modifier = Modifier.size(44.dp)
                                ) { Icon(Icons.Filled.Forward10, "Forward 10 seconds", tint = Color.White, modifier = Modifier.size(28.dp)) }
                            }
                            IconButton(onClick = {
                                resizeIndex = (resizeIndex + 1) % resizeModes.size
                                hint = resizeNames[resizeIndex]
                            }) { Icon(Icons.Filled.AspectRatio, "Aspect ratio", tint = Color.White) }
                        }
                    }
                }
            }

            if (showQueue) {
                Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { showQueue = false } })
                QueuePanel(
                    queue = qItems,
                    current = curIndex,
                    loader = thumbLoader,
                    shuffleOn = shuffleOn,
                    onClose = { showQueue = false },
                    onPick = { i -> exo.seekTo(i, 0L); exo.play() },
                    onRemove = { i ->
                        if (exo.mediaItemCount > 1) exo.removeMediaItem(i) else hint = "Can't remove the last item"
                    },
                    onOrder = { applyOrder(it) },
                    modifier = Modifier.align(Alignment.CenterEnd)
                )
            }

            AnimatedVisibility(visible = showControls && locked, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize()) {
                    IconButton(
                        onClick = { locked = false; showControls = true },
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(16.dp)
                            .background(Color(0x66000000), CircleShape)
                    ) { Icon(Icons.Filled.LockOpen, "Unlock", tint = Color.White) }
                }
            }
        }
    }
}

@Composable
fun PChip(text: String, active: Boolean = false, onClick: () -> Unit) {
    Text(
        text,
        color = if (active) Blue else Color.White,
        fontSize = 15.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    )
}

data class QItem(val uri: String, val title: String, val dur: Long)

@Composable
fun ToolButton(
    label: String,
    active: Boolean = false,
    icon: ImageVector? = null,
    text: String? = null,
    onClick: () -> Unit
) {
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(46.dp).background(if (active) Blue else Color(0xAA1E1E22), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) Icon(icon, label, tint = Color.White, modifier = Modifier.size(24.dp))
            else Text(text ?: "", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.White, fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun QueuePanel(
    queue: List<QItem>,
    current: Int,
    loader: ImageLoader,
    shuffleOn: Boolean,
    onClose: () -> Unit,
    onPick: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onOrder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var menu by remember { mutableStateOf(false) }
    Column(
        modifier
            .fillMaxHeight()
            .widthIn(max = 340.dp)
            .fillMaxWidth(0.92f)
            .background(Color(0xEE0B0F18))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close", tint = Color.White) }
            Text("Queue", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("  (${queue.size})", color = Grey, fontSize = 16.sp)
            Spacer(Modifier.weight(1f))
            Box {
                Row(
                    Modifier.clip(RoundedCornerShape(12.dp)).clickable { menu = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Order", color = Color.White, fontSize = 15.sp)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Filled.SwapVert, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Name A–Z") }, onClick = { menu = false; onOrder("az") })
                    DropdownMenuItem(text = { Text("Name Z–A") }, onClick = { menu = false; onOrder("za") })
                    DropdownMenuItem(text = { Text("Shortest first") }, onClick = { menu = false; onOrder("short") })
                    DropdownMenuItem(text = { Text("Longest first") }, onClick = { menu = false; onOrder("long") })
                    DropdownMenuItem(
                        text = { Text(if (shuffleOn) "Shuffle: on" else "Shuffle: off") },
                        onClick = { menu = false; onOrder("shuffle") }
                    )
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(queue.size) { i ->
                val q = queue[i]
                val isCur = i == current
                val vid = remember(q.uri) { Video(0, q.title, q.dur, Uri.parse(q.uri), "", 0) }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (isCur) Color(0x33FFFFFF) else Color.Transparent)
                        .clickable { onPick(i) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    VideoThumb(vid, loader, Modifier.width(96.dp).height(56.dp), showDuration = q.dur > 0)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        q.title,
                        fontSize = 14.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = if (isCur) Color.White else Color(0xFFB0B7C3),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onRemove(i) }) { Icon(Icons.Filled.Close, "Remove", tint = Color.White) }
                }
            }
        }
    }
}
