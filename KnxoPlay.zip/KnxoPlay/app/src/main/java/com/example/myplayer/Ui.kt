@file:OptIn(ExperimentalFoundationApi::class)

package com.example.myplayer

import android.graphics.BitmapFactory
import android.os.Build
import android.util.Size
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

val Pink = Color(0xFFFF5C8A)

class RowEnv(
    val loader: ImageLoader,
    val selected: Set<String>,
    val favs: Set<String>,
    val toggleSel: (String) -> Unit,
    val toggleFav: (String) -> Unit,
    val share: (android.net.Uri, String) -> Unit,
    val addToPlaylist: (String) -> Unit
) {
    val selecting: Boolean get() = selected.isNotEmpty()
}

private fun Modifier.card(selected: Boolean, onClick: () -> Unit, onLong: () -> Unit): Modifier =
    this
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 5.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(if (selected) Color(0xFF1E3A6B) else CardColor)
        .combinedClickable(onClick = onClick, onLongClick = onLong)

@Composable
fun ItemMenu(isFav: Boolean, onShare: () -> Unit, onFav: () -> Unit, onPlaylist: (() -> Unit)? = null) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, "More", tint = Grey) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Share") },
                leadingIcon = { Icon(Icons.Filled.Share, null) },
                onClick = { open = false; onShare() }
            )
            DropdownMenuItem(
                text = { Text(if (isFav) "Remove from favorites" else "Add to favorites") },
                leadingIcon = { Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null) },
                onClick = { open = false; onFav() }
            )
            if (onPlaylist != null) {
                DropdownMenuItem(
                    text = { Text("Add to playlist") },
                    leadingIcon = { Icon(Icons.Filled.Add, null) },
                    onClick = { open = false; onPlaylist() }
                )
            }
        }
    }
}

@Composable
fun SongArt(song: Song, size: Dp, px: Int = 256) {
    val context = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, song.id) {
        value = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    context.contentResolver.loadThumbnail(song.uri, Size(px, px), null).asImageBitmap()
                } else {
                    context.contentResolver.openInputStream(albumArtUri(song.albumId))?.use {
                        BitmapFactory.decodeStream(it)?.asImageBitmap()
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1C2638)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.MusicNote, null, tint = Color(0xFF6B778C), modifier = Modifier.size(size / 2))
    }
}

@Composable
fun VideoThumb(v: Video, loader: ImageLoader, modifier: Modifier, showDuration: Boolean = false) {
    val context = LocalContext.current
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF1C2638))) {
        AsyncImage(
            model = remember(v.uri) { ImageRequest.Builder(context).data(v.uri).videoFrameMillis(1000).build() },
            imageLoader = loader,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (showDuration) {
            Text(
                formatDuration(v.durationMs),
                fontSize = 11.sp,
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
    }
}

@Composable
fun VideoItemRow(v: Video, env: RowEnv, onPlay: () -> Unit) {
    val context = LocalContext.current
    val key = v.uri.toString()
    val sel = key in env.selected
    val fav = key in env.favs
    Row(
        Modifier
            .card(sel, { if (env.selecting) env.toggleSel(key) else onPlay() }, { env.toggleSel(key) })
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VideoThumb(v, env.loader, Modifier.width(128.dp).height(76.dp), showDuration = true)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(formatSize(v.sizeBytes), fontSize = 13.sp, color = Grey)
                if (fav) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.Favorite, null, tint = Pink, modifier = Modifier.size(14.dp))
                }
            }
        }
        if (sel) Icon(Icons.Filled.CheckCircle, null, tint = Blue, modifier = Modifier.padding(end = 14.dp))
        else ItemMenu(fav, { env.share(v.uri, "video/*") }, { env.toggleFav(key) })
    }
}

@Composable
fun SongItemRow(s: Song, env: RowEnv, onPlay: () -> Unit) {
    val key = s.uri.toString()
    val sel = key in env.selected
    val fav = key in env.favs
    Row(
        Modifier
            .card(sel, { if (env.selecting) env.toggleSel(key) else onPlay() }, { env.toggleSel(key) })
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArt(s, 60.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s.artist, fontSize = 13.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (fav) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.Favorite, null, tint = Pink, modifier = Modifier.size(14.dp))
                }
            }
        }
        if (sel) Icon(Icons.Filled.CheckCircle, null, tint = Blue, modifier = Modifier.padding(end = 14.dp))
        else ItemMenu(fav, { env.share(s.uri, "audio/*") }, { env.toggleFav(key) }, { env.addToPlaylist(key) })
    }
}

@Composable
fun VideoList(list: List<Video>, env: RowEnv) {
    val context = LocalContext.current
    LazyColumn(Modifier.fillMaxSize()) {
        items(list.size, key = { list[it].uri.toString() }) { i ->
            VideoItemRow(list[i], env) { context.playVideos(list, i) }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun SongList(list: List<Song>, env: RowEnv, onPlay: (Int) -> Unit, header: @Composable () -> Unit = {}) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { header() }
        items(list.size, key = { list[it].uri.toString() }) { i ->
            SongItemRow(list[i], env) { onPlay(i) }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp))
}

@Composable
fun FavoritesList(vids: List<Video>, songs: List<Song>, env: RowEnv, onPlaySong: (Int) -> Unit) {
    val context = LocalContext.current
    if (vids.isEmpty() && songs.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
            Text(
                "No favorites yet.\nUse ⋮ on any video or song, or long-press to select.",
                color = Grey,
                textAlign = TextAlign.Center
            )
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            if (vids.isNotEmpty()) {
                item { SectionTitle("Videos") }
                items(vids.size, key = { "v" + vids[it].uri }) { i ->
                    VideoItemRow(vids[i], env) { context.playVideos(vids, i) }
                }
            }
            if (songs.isNotEmpty()) {
                item { SectionTitle("Songs") }
                items(songs.size, key = { "s" + songs[it].uri }) { i ->
                    SongItemRow(songs[i], env) { onPlaySong(i) }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun FolderList(videos: List<Video>, loader: ImageLoader, header: @Composable () -> Unit = {}, onOpen: (String) -> Unit) {
    val folders = remember(videos) { videos.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() } }
    LazyColumn(Modifier.fillMaxSize()) {
        item { header() }
        items(folders, key = { it.first }) { (name, list) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 5.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardColor)
                    .clickable { onOpen(name) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(64.dp)) {
                    VideoThumb(list.first(), loader, Modifier.fillMaxSize())
                    Box(
                        Modifier.align(Alignment.BottomStart).padding(4.dp).size(20.dp)
                            .background(Color(0xAA000000), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Folder, null, tint = Blue, modifier = Modifier.size(14.dp)) }
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (list.size == 1) "1 video" else "${list.size} videos", fontSize = 13.sp, color = Grey)
                }
            }
        }
        item { Spacer(Modifier.height(96.dp)) }
    }
}

@Composable
fun GroupList(
    groups: List<Pair<String, List<Song>>>,
    icon: ImageVector,
    header: @Composable () -> Unit = {},
    onOpen: (String) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { header() }
        items(groups, key = { it.first }) { (name, list) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 5.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardColor)
                    .clickable { onOpen(name) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1C2638)),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (list.size == 1) "1 song" else "${list.size} songs", fontSize = 13.sp, color = Grey)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun DetailHeader(name: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        Text(
            name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        trailing()
    }
}

@Composable
fun SelectionBar(
    count: Int,
    allFav: Boolean,
    inPlaylist: Boolean,
    hasSongs: Boolean,
    onClose: () -> Unit,
    onShare: () -> Unit,
    onFav: () -> Unit,
    onMove: () -> Unit,
    onCopy: () -> Unit,
    onAddPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    modifier: Modifier = Modifier
) {
    var open by remember { mutableStateOf(false) }
    Row(
        modifier.fillMaxWidth().height(68.dp).background(Color(0xFF16213A)).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Cancel") }
        Text("$count selected", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        IconButton(onClick = onShare) { Icon(Icons.Filled.Share, "Share") }
        IconButton(onClick = onFav) {
            Icon(
                if (allFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                "Favorite",
                tint = if (allFav) Pink else Color.White
            )
        }
        Box {
            IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, "More") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("Move to…") }, onClick = { open = false; onMove() })
                DropdownMenuItem(text = { Text("Copy to…") }, onClick = { open = false; onCopy() })
                if (hasSongs) {
                    DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { open = false; onAddPlaylist() })
                }
                if (inPlaylist) {
                    DropdownMenuItem(text = { Text("Remove from playlist") }, onClick = { open = false; onRemoveFromPlaylist() })
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(
    song: Song?,
    title: String,
    artist: String,
    playing: Boolean,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    Box(Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF1B2640))
                .clickable { onOpen() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (song != null) SongArt(song, 44.dp)
            else Icon(Icons.Filled.MusicNote, null, tint = Blue, modifier = Modifier.padding(10.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (artist.isNotEmpty()) Text(artist, fontSize = 12.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onToggle) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause")
            }
            IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, "Next") }
        }
    }
}

@Composable
fun NowPlayingScreen(
    c: MediaController,
    song: Song?,
    title: String,
    artist: String,
    playing: Boolean,
    onClose: () -> Unit
) {
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(c.shuffleModeEnabled) }
    var repeat by remember { mutableIntStateOf(c.repeatMode) }

    LaunchedEffect(c) {
        while (true) {
            if (!dragging) {
                position = c.currentPosition.coerceAtLeast(0L)
                duration = c.duration.coerceAtLeast(0L)
            }
            delay(400)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF172544), Color(0xFF05070C), Color.Black)))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth()) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.KeyboardArrowDown, "Close", modifier = Modifier.size(32.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            if (song != null) SongArt(song, 300.dp, 800)
            else Box(Modifier.size(300.dp).clip(RoundedCornerShape(24.dp)).background(Color(0xFF1C2638)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.MusicNote, null, tint = Color(0xFF6B778C), modifier = Modifier.size(120.dp))
            }
            Spacer(Modifier.height(28.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(artist, fontSize = 15.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(24.dp))
            Slider(
                value = position.toFloat(),
                onValueChange = { dragging = true; position = it.toLong() },
                onValueChangeFinished = { c.seekTo(position); dragging = false },
                valueRange = 0f..duration.coerceAtLeast(1L).toFloat()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(position), fontSize = 13.sp, color = Grey)
                Text(formatDuration(duration), fontSize = 13.sp, color = Grey)
            }
            Spacer(Modifier.height(16.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { shuffle = !shuffle; c.shuffleModeEnabled = shuffle }) {
                    Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (shuffle) Blue else Grey)
                }
                IconButton(onClick = { c.seekToPreviousMediaItem() }) {
                    Icon(Icons.Filled.SkipPrevious, "Previous", modifier = Modifier.size(36.dp))
                }
                IconButton(
                    onClick = { if (c.isPlaying) c.pause() else c.play() },
                    modifier = Modifier.size(72.dp).background(Blue, RoundedCornerShape(36.dp))
                ) {
                    Icon(
                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        "Play/Pause",
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = { c.seekToNextMediaItem() }) {
                    Icon(Icons.Filled.SkipNext, "Next", modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = {
                    repeat = when (repeat) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                    c.repeatMode = repeat
                }) {
                    Icon(
                        if (repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        "Repeat",
                        tint = if (repeat == Player.REPEAT_MODE_OFF) Grey else Blue
                    )
                }
            }
            Spacer(Modifier.weight(1.2f))
        }
    }
}

@Composable
fun TextInputDialog(title: String, confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ChoiceDialog(
    title: String,
    options: List<String>,
    extraLabel: String,
    onPick: (String) -> Unit,
    onExtra: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { o ->
                    Text(
                        o.trimEnd('/'),
                        modifier = Modifier.fillMaxWidth().clickable { onPick(o) }.padding(vertical = 12.dp)
                    )
                }
                Text(
                    extraLabel,
                    color = Blue,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth().clickable { onExtra() }.padding(vertical = 12.dp)
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun WorkingDialog() {
    AlertDialog(
        onDismissRequest = {},
        containerColor = CardColor,
        confirmButton = {},
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp))
                Spacer(Modifier.width(16.dp))
                Text("Working…")
            }
        }
    )
}

@Composable
private fun LinkRow(label: String, link: String, url: String) {
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable { context.openUrl(url) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Grey, fontSize = 13.sp, modifier = Modifier.width(72.dp))
        Text(link, color = Blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val version = remember {
        try { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painterResource(R.drawable.knxo_logo), null,
                    Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Knxo Play", fontWeight = FontWeight.Bold)
                    Text("Version $version", fontSize = 13.sp, color = Grey)
                }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("A modern video and music player with gestures, subtitles, picture-in-picture and background music.")
                Spacer(Modifier.height(16.dp))
                Text("Developer", color = Grey, fontSize = 12.sp)
                Text("Kenasa", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                LinkRow("Telegram", "t.me/kenexo", "https://t.me/kenexo")
                LinkRow("Channel", "t.me/Ethiopsiphonn", "https://t.me/Ethiopsiphonn")
                Spacer(Modifier.height(16.dp))
                Text("Thank you", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Thank you for using Knxo Play. Your support and feedback help it grow.")
                Spacer(Modifier.height(8.dp))
                Text("Knxo Play ስለተጠቀሙ እናመሰግናለን። ድጋፍዎ እና አስተያየትዎ እንድናድግ ይረዱናል።")
                Spacer(Modifier.height(14.dp))
                Text(
                    "Built with open-source libraries: Android Media3 (ExoPlayer), Jetpack Compose and Coil.",
                    color = Grey, fontSize = 12.sp
                )
            }
        }
    )
}

@Composable
private fun QuickItem(icon: ImageVector, tint: Color, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(60.dp).background(Color(0xFF1C2638), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = tint, modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp)
    }
}

@Composable
fun QuickActions(onAll: () -> Unit, onRecent: () -> Unit, onMusic: () -> Unit, onStream: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        QuickItem(Icons.Filled.GridView, Color(0xFFFFB454), "All videos", onAll)
        QuickItem(Icons.Filled.Schedule, Color(0xFF7BC97E), "Recent", onRecent)
        QuickItem(Icons.Filled.MusicNote, Color(0xFFBA68C8), "Music", onMusic)
        QuickItem(Icons.Filled.Public, Color(0xFF4F9BFF), "Stream", onStream)
    }
}
