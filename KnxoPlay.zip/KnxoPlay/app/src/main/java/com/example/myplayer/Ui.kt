@file:OptIn(ExperimentalFoundationApi::class)

package com.example.myplayer

import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notes
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Timer
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Size
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

val Pink = Color(0xFFFF5C8A)

class RowEnv(
    val loader: ImageLoader,
    val selected: Set<String>,
    val favs: Set<String>,
    val toggleSel: (String) -> Unit,
    val toggleFav: (String) -> Unit,
    val share: (android.net.Uri, String) -> Unit,
    val addToPlaylist: (String) -> Unit,
    val playNext: (String) -> Unit = {},
    val addToQueue: (String) -> Unit = {}
) {
    val selecting: Boolean get() = selected.isNotEmpty()
}

private fun Modifier.card(selected: Boolean, onClick: () -> Unit, onLong: () -> Unit): Modifier =
    this
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 5.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(if (selected) SelBg else CardColor)
        .combinedClickable(onClick = onClick, onLongClick = onLong)

@Composable
fun ItemMenu(
    isFav: Boolean,
    onShare: () -> Unit,
    onFav: () -> Unit,
    onPlaylist: (() -> Unit)? = null,
    onPlayNext: (() -> Unit)? = null,
    onQueue: (() -> Unit)? = null
) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, tr("More"), tint = Grey) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text(tr("Share")) },
                leadingIcon = { Icon(Icons.Filled.Share, null) },
                onClick = { open = false; onShare() }
            )
            DropdownMenuItem(
                text = { Text(if (isFav) tr("Remove from favorites") else tr("Add to favorites")) },
                leadingIcon = { Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null) },
                onClick = { open = false; onFav() }
            )
            if (onPlayNext != null) {
                DropdownMenuItem(
                    text = { Text(tr("Play next")) },
                    leadingIcon = { Icon(Icons.Filled.SkipNext, null) },
                    onClick = { open = false; onPlayNext() }
                )
            }
            if (onQueue != null) {
                DropdownMenuItem(
                    text = { Text(tr("Add to queue")) },
                    leadingIcon = { Icon(Icons.Filled.QueueMusic, null) },
                    onClick = { open = false; onQueue() }
                )
            }
            if (onPlaylist != null) {
                DropdownMenuItem(
                    text = { Text(tr("Add to playlist")) },
                    leadingIcon = { Icon(Icons.Filled.Add, null) },
                    onClick = { open = false; onPlaylist() }
                )
            }
        }
    }
}

@Composable
fun SongArt(song: Song, size: Dp, px: Int = 256, modifier: Modifier = Modifier.size(size)) {
    val context = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, song.id) {
        value = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    context.contentResolver.loadThumbnail(song.uri, Size(px, px), null).asImageBitmap()
                } else {
                    context.contentResolver.openInputStream(albumArtUri(song.albumId))?.use {
                        BitmapFactory.decodeStream(it)?.asImageBitmap()
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(Card2),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.MusicNote, null, tint = Grey, modifier = Modifier.size(size / 2))
    }
}

@Composable
fun VideoThumb(v: Video, loader: ImageLoader, modifier: Modifier, showDuration: Boolean = false) {
    val context = LocalContext.current
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(Card2)) {
        AsyncImage(
            model = remember(v.uri) { ImageRequest.Builder(context).data(v.uri).videoFrameMillis(1000).build() },
            imageLoader = loader,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (showDuration) {
            Text(
                formatDuration(v.durationMs),
                fontSize = 11.sp,
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
    }
}

@Composable
fun VideoItemRow(v: Video, env: RowEnv, opts: ViewOpts = ViewOpts(), onPlay: () -> Unit) {
    val context = LocalContext.current
    val key = v.uri.toString()
    val sel = key in env.selected
    val fav = key in env.favs
    Row(
        Modifier
            .card(sel, { if (env.selecting) env.toggleSel(key) else onPlay() }, { env.toggleSel(key) })
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VideoThumb(v, env.loader, Modifier.width(128.dp).height(76.dp), showDuration = opts.showDuration)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (opts.showSize) Text(formatSize(v.sizeBytes), fontSize = 13.sp, color = Grey)
                if (fav) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.Favorite, null, tint = Pink, modifier = Modifier.size(14.dp))
                }
            }
        }
        if (sel) Icon(Icons.Filled.CheckCircle, null, tint = Blue, modifier = Modifier.padding(end = 14.dp))
        else ItemMenu(fav, { env.share(v.uri, "video/*") }, { env.toggleFav(key) })
    }
}

@Composable
fun SongItemRow(s: Song, env: RowEnv, onPlay: () -> Unit) {
    val key = s.uri.toString()
    val sel = key in env.selected
    val fav = key in env.favs
    Row(
        Modifier
            .card(sel, { if (env.selecting) env.toggleSel(key) else onPlay() }, { env.toggleSel(key) })
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArt(s, 60.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s.artist, fontSize = 13.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (fav) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.Favorite, null, tint = Pink, modifier = Modifier.size(14.dp))
                }
            }
        }
        if (sel) Icon(Icons.Filled.CheckCircle, null, tint = Blue, modifier = Modifier.padding(end = 14.dp))
        else ItemMenu(
            fav,
            { env.share(s.uri, "audio/*") },
            { env.toggleFav(key) },
            { env.addToPlaylist(key) },
            { env.playNext(key) },
            { env.addToQueue(key) }
        )
    }
}

@Composable
fun VideoGridCard(v: Video, env: RowEnv, opts: ViewOpts, onPlay: () -> Unit) {
    val key = v.uri.toString()
    val sel = key in env.selected
    val fav = key in env.favs
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (sel) SelBg else CardColor)
            .combinedClickable(
                onClick = { if (env.selecting) env.toggleSel(key) else onPlay() },
                onLongClick = { env.toggleSel(key) }
            )
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.6f)) {
            VideoThumb(v, env.loader, Modifier.fillMaxSize(), showDuration = opts.showDuration)
            if (sel) {
                Icon(Icons.Filled.CheckCircle, null, tint = Blue, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            } else if (fav) {
                Icon(Icons.Filled.Favorite, null, tint = Pink, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp))
            }
        }
        Row(Modifier.padding(start = 10.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(v.title, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (opts.showSize) Text(formatSize(v.sizeBytes), fontSize = 12.sp, color = Grey)
            }
            if (!sel) ItemMenu(fav, { env.share(v.uri, "video/*") }, { env.toggleFav(key) })
        }
    }
}

@Composable
fun VideoList(src: List<Video>, env: RowEnv, opts: ViewOpts = ViewOpts(), sorted: Boolean = true) {
    val context = LocalContext.current
    val list = remember(src, opts.sortKey, opts.desc, sorted) { if (sorted) sortVideos(src, opts) else src }
    if (opts.grid) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(opts.cols),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list.size, key = { list[it].uri.toString() }) { i ->
                VideoGridCard(list[i], env, opts) { context.playVideos(list, i) }
            }
            item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(24.dp)) }
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            items(list.size, key = { list[it].uri.toString() }) { i ->
                VideoItemRow(list[i], env, opts) { context.playVideos(list, i) }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun SongGridCard(s: Song, env: RowEnv, onPlay: () -> Unit) {
    val key = s.uri.toString()
    val sel = key in env.selected
    val fav = key in env.favs
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (sel) SelBg else CardColor)
            .combinedClickable(
                onClick = { if (env.selecting) env.toggleSel(key) else onPlay() },
                onLongClick = { env.toggleSel(key) }
            )
    ) {
        Box(Modifier.fillMaxWidth().padding(8.dp)) {
            SongArt(s, 120.dp, 400, Modifier.fillMaxWidth().aspectRatio(1f))
            if (sel) {
                Icon(Icons.Filled.CheckCircle, null, tint = Blue, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            } else if (fav) {
                Icon(Icons.Filled.Favorite, null, tint = Pink, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(18.dp))
            }
        }
        Row(Modifier.padding(start = 10.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.title, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(s.artist, fontSize = 12.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (!sel) {
                ItemMenu(
                    fav,
                    { env.share(s.uri, "audio/*") },
                    { env.toggleFav(key) },
                    { env.addToPlaylist(key) },
                    { env.playNext(key) },
                    { env.addToQueue(key) }
                )
            }
        }
    }
}

@Composable
fun SongList(
    list: List<Song>,
    env: RowEnv,
    onPlay: (Int) -> Unit,
    header: @Composable () -> Unit = {},
    opts: ViewOpts = ViewOpts()
) {
    if (opts.grid) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(opts.cols),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { header() }
            items(list.size, key = { list[it].uri.toString() }) { i ->
                SongGridCard(list[i], env) { onPlay(i) }
            }
            item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(24.dp)) }
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            item { header() }
            items(list.size, key = { list[it].uri.toString() }) { i ->
                SongItemRow(list[i], env) { onPlay(i) }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp))
}

@Composable
fun FavoritesList(vids: List<Video>, songs: List<Song>, env: RowEnv, onPlaySong: (Int) -> Unit) {
    val context = LocalContext.current
    if (vids.isEmpty() && songs.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
            Text(
                tr("No favorites yet.\nUse ⋮ on any video or song, or long-press to select."),
                color = Grey,
                textAlign = TextAlign.Center
            )
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            if (vids.isNotEmpty()) {
                item { SectionTitle(tr("Videos")) }
                items(vids.size, key = { "v" + vids[it].uri }) { i ->
                    VideoItemRow(vids[i], env) { context.playVideos(vids, i) }
                }
            }
            if (songs.isNotEmpty()) {
                item { SectionTitle(tr("Songs")) }
                items(songs.size, key = { "s" + songs[it].uri }) { i ->
                    SongItemRow(songs[i], env) { onPlaySong(i) }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun FolderMenu(onPlayAll: () -> Unit, onOpen: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, tr("More"), tint = Grey) }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(tr("Play all")) },
                leadingIcon = { Icon(Icons.Filled.PlayArrow, null) },
                onClick = { menu = false; onPlayAll() }
            )
            DropdownMenuItem(text = { Text(tr("Open")) }, onClick = { menu = false; onOpen() })
        }
    }
}

@Composable
private fun FolderGridCard(
    name: String,
    list: List<Video>,
    loader: ImageLoader,
    onOpen: () -> Unit,
    onPlayAll: () -> Unit
) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).background(CardColor).clickable(onClick = onOpen)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.6f)) {
            VideoThumb(list.first(), loader, Modifier.fillMaxSize())
            Box(
                Modifier.align(Alignment.BottomStart).padding(6.dp).size(22.dp)
                    .background(Color(0xAA000000), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Folder, null, tint = Blue, modifier = Modifier.size(15.dp)) }
        }
        Row(Modifier.padding(start = 10.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(trVideos(list.size), fontSize = 12.sp, color = Grey)
            }
            FolderMenu(onPlayAll, onOpen)
        }
    }
}

@Composable
fun FolderList(
    videos: List<Video>,
    loader: ImageLoader,
    header: @Composable () -> Unit = {},
    opts: ViewOpts = ViewOpts(),
    onPlayAll: (String) -> Unit,
    onOpen: (String) -> Unit
) {
    val folders = remember(videos, opts.sortKey, opts.desc) {
        sortFolders(videos.groupBy { it.folder }.toList(), opts)
    }
    if (opts.grid) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(opts.cols),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { header() }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    trFolders(folders.size),
                    fontSize = 12.sp,
                    color = Grey,
                    modifier = Modifier.padding(start = 8.dp, top = 8.dp)
                )
            }
            items(folders.size, key = { folders[it].first }) { i ->
                val name = folders[i].first
                val list = folders[i].second
                FolderGridCard(name, list, loader, { onOpen(name) }, { onPlayAll(name) })
            }
            item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(96.dp)) }
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            item { header() }
            item {
                Text(
                    trFolders(folders.size),
                    fontSize = 12.sp,
                    color = Grey,
                    modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp)
                )
            }
            items(folders, key = { it.first }) { (name, list) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(CardColor)
                        .clickable { onOpen(name) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(64.dp)) {
                        VideoThumb(list.first(), loader, Modifier.fillMaxSize())
                        Box(
                            Modifier.align(Alignment.BottomStart).padding(4.dp).size(20.dp)
                                .background(Color(0xAA000000), RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Folder, null, tint = Blue, modifier = Modifier.size(14.dp)) }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(trVideos(list.size), fontSize = 13.sp, color = Grey)
                    }
                    FolderMenu({ onPlayAll(name) }, { onOpen(name) })
                }
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@Composable
fun GroupList(
    groups: List<Pair<String, List<Song>>>,
    icon: ImageVector,
    header: @Composable () -> Unit = {},
    onOpen: (String) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { header() }
        items(groups, key = { it.first }) { (name, list) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 5.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardColor)
                    .clickable { onOpen(name) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Card2),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(trSongs(list.size), fontSize = 13.sp, color = Grey)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun DetailHeader(name: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back")) }
        Text(
            name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        trailing()
    }
}

@Composable
fun SelectionBar(
    count: Int,
    allFav: Boolean,
    inPlaylist: Boolean,
    hasSongs: Boolean,
    onClose: () -> Unit,
    onShare: () -> Unit,
    onFav: () -> Unit,
    onMove: () -> Unit,
    onCopy: () -> Unit,
    onPrivate: () -> Unit,
    onAddPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onPlayNext: () -> Unit = {},
    onQueue: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var open by remember { mutableStateOf(false) }
    Row(
        modifier.fillMaxWidth().height(68.dp).background(BarBg).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, tr("Cancel")) }
        Text(trSelected(count), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        IconButton(onClick = onShare) { Icon(Icons.Filled.Share, tr("Share")) }
        IconButton(onClick = onFav) {
            Icon(
                if (allFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                tr("Favorite"),
                tint = if (allFav) Pink else OnBg
            )
        }
        Box {
            IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, tr("More")) }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text(tr("Move to…")) }, onClick = { open = false; onMove() })
                DropdownMenuItem(text = { Text(tr("Copy to…")) }, onClick = { open = false; onCopy() })
                DropdownMenuItem(text = { Text(tr("Move to private folder")) }, onClick = { open = false; onPrivate() })
                if (hasSongs) {
                    DropdownMenuItem(text = { Text(tr("Play next")) }, onClick = { open = false; onPlayNext() })
                    DropdownMenuItem(text = { Text(tr("Add to queue")) }, onClick = { open = false; onQueue() })
                    DropdownMenuItem(text = { Text(tr("Add to playlist")) }, onClick = { open = false; onAddPlaylist() })
                }
                if (inPlaylist) {
                    DropdownMenuItem(text = { Text(tr("Remove from playlist")) }, onClick = { open = false; onRemoveFromPlaylist() })
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(
    song: Song?,
    title: String,
    artist: String,
    playing: Boolean,
    onOpen: () -> Unit,
    onPrev: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    Box(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(BarBg)
                .clickable { onOpen() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (song != null) SongArt(song, 44.dp)
            else Icon(Icons.Filled.MusicNote, null, tint = Blue, modifier = Modifier.padding(10.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (artist.isNotEmpty()) Text(artist, fontSize = 12.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onPrev) { Icon(Icons.Filled.SkipPrevious, tr("Previous")) }
            IconButton(onClick = onToggle) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause")
            }
            IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, tr("Next")) }
        }
    }
}

@Composable
fun NowPlayingScreen(
    c: MediaController,
    song: Song?,
    title: String,
    artist: String,
    playing: Boolean,
    onClose: () -> Unit
) {
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(c.shuffleModeEnabled) }
    var repeat by remember { mutableIntStateOf(c.repeatMode) }
    var showSleep by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }

    LaunchedEffect(c) {
        while (true) {
            if (!dragging) {
                position = c.currentPosition.coerceAtLeast(0L)
                duration = c.duration.coerceAtLeast(0L)
            }
            delay(400)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(KnxoColors.theme.bgTop, KnxoColors.theme.bgMid, KnxoColors.theme.bgBottom)))
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.KeyboardArrowDown, tr("Close"), modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.weight(1f))
                val sleepOn = SleepTimer.remainingMs > 0L || SleepTimer.endOfTrack
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (sleepOn) Blue else Card2)
                        .clickable { showSleep = true }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Timer, tr("Sleep timer"),
                        tint = if (sleepOn) Color.White else Grey,
                        modifier = Modifier.size(20.dp)
                    )
                    if (sleepOn) {
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (SleepTimer.endOfTrack) tr("End of song") else formatDuration(SleepTimer.remainingMs),
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            }
            if (showSleep) {
                MusicSleepDialog(
                    active = SleepTimer.remainingMs > 0L || SleepTimer.endOfTrack,
                    onPick = { m ->
                        when {
                            m > 0 -> SleepTimer.start(m)
                            m == -1 -> SleepTimer.endOfSong()
                            else -> SleepTimer.cancel()
                        }
                        showSleep = false
                    },
                    onDismiss = { showSleep = false }
                )
            }
            Spacer(Modifier.weight(1f))
            if (showLyrics && song != null) {
                LyricsPanel(song, position, Modifier.fillMaxWidth().height(300.dp))
            } else if (song != null) SongArt(song, 300.dp, 800)
            else Box(Modifier.size(300.dp).clip(RoundedCornerShape(24.dp)).background(Card2), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.MusicNote, null, tint = Grey, modifier = Modifier.size(120.dp))
            }
            Spacer(Modifier.height(28.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(artist, fontSize = 15.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(24.dp))
            Slider(
                value = position.toFloat(),
                onValueChange = { dragging = true; position = it.toLong() },
                onValueChangeFinished = { c.seekTo(position); dragging = false },
                valueRange = 0f..duration.coerceAtLeast(1L).toFloat()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(position), fontSize = 13.sp, color = Grey)
                Text(formatDuration(duration), fontSize = 13.sp, color = Grey)
            }
            Spacer(Modifier.height(16.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { shuffle = !shuffle; c.shuffleModeEnabled = shuffle }) {
                    Icon(Icons.Filled.Shuffle, tr("Shuffle"), tint = if (shuffle) Blue else Grey)
                }
                IconButton(onClick = { c.seekToPreviousMediaItem() }) {
                    Icon(Icons.Filled.SkipPrevious, tr("Previous"), modifier = Modifier.size(36.dp))
                }
                IconButton(
                    onClick = { if (c.isPlaying) c.pause() else c.play() },
                    modifier = Modifier.size(72.dp).background(Blue, RoundedCornerShape(36.dp))
                ) {
                    Icon(
                        if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        "Play/Pause",
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = { c.seekToNextMediaItem() }) {
                    Icon(Icons.Filled.SkipNext, tr("Next"), modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = {
                    repeat = when (repeat) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                    c.repeatMode = repeat
                }) {
                    Icon(
                        if (repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        tr("Repeat"),
                        tint = if (repeat == Player.REPEAT_MODE_OFF) Grey else Blue
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(40.dp)) {
                IconButton(onClick = { c.seekTo((c.currentPosition - 10_000).coerceAtLeast(0L)) }) {
                    Icon(Icons.Filled.Replay10, tr("Back 10 seconds"), modifier = Modifier.size(32.dp))
                }
                IconButton(onClick = { c.seekTo((c.currentPosition + 10_000).coerceAtMost(duration.coerceAtLeast(1L))) }) {
                    Icon(Icons.Filled.Forward10, tr("Forward 10 seconds"), modifier = Modifier.size(32.dp))
                }
                IconButton(onClick = { showLyrics = !showLyrics }, enabled = song != null) {
                    Icon(
                        Icons.Filled.Notes, tr("Lyrics"),
                        tint = if (showLyrics) Blue else Grey,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
            Spacer(Modifier.weight(1.2f))
        }
    }
}

@Composable
fun TextInputDialog(title: String, confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } }
    )
}

@Composable
fun ChoiceDialog(
    title: String,
    options: List<String>,
    extraLabel: String,
    onPick: (String) -> Unit,
    onExtra: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { o ->
                    Text(
                        o.trimEnd('/'),
                        modifier = Modifier.fillMaxWidth().clickable { onPick(o) }.padding(vertical = 12.dp)
                    )
                }
                Text(
                    extraLabel,
                    color = Blue,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth().clickable { onExtra() }.padding(vertical = 12.dp)
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } }
    )
}

@Composable
fun WorkingDialog() {
    AlertDialog(
        onDismissRequest = {},
        containerColor = CardColor,
        confirmButton = {},
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp))
                Spacer(Modifier.width(16.dp))
                Text(tr("Working…"))
            }
        }
    )
}

@Composable
private fun LinkRow(label: String, link: String, url: String) {
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable { context.openUrl(url) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Grey, fontSize = 13.sp, modifier = Modifier.width(72.dp))
        Text(link, color = Blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SettingRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Blue,
                uncheckedThumbColor = Grey,
                uncheckedTrackColor = Card2
            )
        )
    }
}


@Composable
private fun SectionLabel(text: String) {
    Text(
        text, color = Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 6.dp, top = 18.dp, bottom = 6.dp)
    )
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardColor).padding(horizontal = 14.dp, vertical = 6.dp),
        content = content
    )
}

@Composable
private fun ClickRow(title: String, subtitle: String, onClick: () -> Unit, leading: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            Text(subtitle, fontSize = 13.sp, color = Grey)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Grey)
    }
}

@Composable
fun AboutSection() {
    val context = LocalContext.current
    val version = remember {
        try { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardColor).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.knxo_logo), null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Knxo Play", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(trVersion(version), fontSize = 13.sp, color = Grey)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(tr("A modern video and music player with gestures, subtitles, picture-in-picture and background music."))
        Spacer(Modifier.height(16.dp))
        Text(tr("Developer"), color = Grey, fontSize = 12.sp)
        Text("Kenasa", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LinkRow("Telegram", "t.me/kenexo", "https://t.me/kenexo")
        LinkRow(tr("Channel"), "t.me/Ethiopsiphonn", "https://t.me/Ethiopsiphonn")
        Spacer(Modifier.height(16.dp))
        Text(tr("Thank you"), fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(tr("Thank you for using Knxo Play. Your support and feedback help it grow."))
        Spacer(Modifier.height(8.dp))
        Text("Knxo Play ስለተጠቀሙ እናመሰግናለን። ድጋፍዎ እና አስተያየትዎ እንድናድግ ይረዱናል።")
        Spacer(Modifier.height(14.dp))
        Text(
            tr("Built with open-source libraries: Android Media3 (ExoPlayer), Jetpack Compose and Coil."),
            color = Grey, fontSize = 12.sp
        )
    }
}

@Composable
fun SettingsScreen(
    lib: Library,
    onBack: () -> Unit,
    onTheme: () -> Unit,
    onShareApp: () -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onLanguage: () -> Unit
) {
    var keepOn by remember { mutableStateOf(lib.flag("keep_on", true)) }
    var autoPip by remember { mutableStateOf(lib.flag("auto_pip", true)) }
    var hideSecs by remember { mutableStateOf(lib.intPref("hide_secs", 8)) }
    val t = KnxoColors.theme
    CompositionLocalProvider(LocalContentColor provides OnBg) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(t.bgTop, t.bgMid, t.bgBottom)))
                .pointerInput(Unit) { detectTapGestures { } }
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back")) }
                Text(tr("Settings"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                SectionLabel(tr("Appearance"))
                CardBox {
                    ClickRow(tr("Theme"), tr(t.name), onTheme) {
                        Box(
                            Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(t.bgTop, t.card)))
                                .border(1.dp, Grey, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) { Box(Modifier.size(14.dp).background(t.accent, CircleShape)) }
                    }
                }
                SectionLabel(tr("Language"))
                CardBox {
                    ClickRow(tr("Language"), if (Lang.code == "am") "አማርኛ" else "English", onLanguage) {
                        Icon(Icons.Filled.Language, null, tint = Blue, modifier = Modifier.size(28.dp))
                    }
                }
                SectionLabel(tr("Playback"))
                CardBox {
                    SettingRow(tr("Keep screen on while playing"), keepOn) { keepOn = it; lib.setFlag("keep_on", it) }
                    SettingRow(tr("Picture-in-picture when leaving"), autoPip) { autoPip = it; lib.setFlag("auto_pip", it) }
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("Hide player controls after"), Modifier.weight(1f))
                        TextButton(onClick = {
                            val opts = listOf(5, 8, 12, 20)
                            hideSecs = opts[(opts.indexOf(hideSecs) + 1) % opts.size]
                            lib.setIntPref("hide_secs", hideSecs)
                        }) { Text("${hideSecs}s") }
                    }
                }
                SectionLabel(tr("Backup"))
                CardBox {
                    ClickRow(tr("Back up favorites & playlists"), tr("Save to a file or send it"), onBackup) {
                        Icon(Icons.Filled.Backup, null, tint = Blue, modifier = Modifier.size(28.dp))
                    }
                    ClickRow(tr("Restore from backup"), tr("Pick a Knxo Play backup file"), onRestore) {
                        Icon(Icons.Filled.Restore, null, tint = Blue, modifier = Modifier.size(28.dp))
                    }
                }
                SectionLabel(tr("Share"))
                CardBox {
                    ClickRow(tr("Share this app"), tr("Send Knxo Play to a friend"), onShareApp) {
                        Icon(Icons.Filled.Share, null, tint = Blue, modifier = Modifier.size(28.dp))
                    }
                }
                SectionLabel(tr("About"))
                AboutSection()
                Spacer(Modifier.height(28.dp))
            }
        }
    }
}

@Composable
private fun ThemePreview(t: AppTheme, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(t.bgTop, t.bgMid)))
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 10.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Knxo Play", color = t.onBg, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.Search, null, tint = t.onBg, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Filled.MoreVert, null, tint = t.onBg, modifier = Modifier.size(18.dp))
        }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(tr("Songs"), tr("Artists"), tr("Albums")).forEachIndexed { i, label ->
                Text(
                    label,
                    color = if (i == 0) Color.White else t.grey,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (i == 0) t.accent else t.card)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(5) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(t.card).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)).background(t.card2))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Box(Modifier.width(96.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(t.onBg.copy(alpha = 0.85f)))
                        Spacer(Modifier.height(5.dp))
                        Box(Modifier.width(56.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(t.grey))
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(t.nav).padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Icon(Icons.Filled.VideoLibrary, null, tint = t.accent, modifier = Modifier.size(22.dp))
            Icon(Icons.Filled.MusicNote, null, tint = t.grey, modifier = Modifier.size(22.dp))
            Icon(Icons.Filled.LibraryMusic, null, tint = t.grey, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
fun ThemePickerScreen(current: Int, onBack: () -> Unit, onUse: (Int) -> Unit) {
    var sel by remember { mutableStateOf(current) }
    val t = Themes[sel]
    CompositionLocalProvider(LocalContentColor provides t.onBg) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(t.bgTop, t.bgMid, t.bgBottom)))
                .pointerInput(Unit) { detectTapGestures { } }
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.fillMaxWidth().padding(8.dp)) {
                IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back"))
                }
                Text(tr(t.name), fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Center))
            }
            Spacer(Modifier.weight(1f))
            ThemePreview(t, Modifier.width(240.dp).height(420.dp))
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Themes.forEachIndexed { i, th ->
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(th.bgTop, th.card)))
                            .border(2.dp, if (i == sel) t.onBg else t.grey.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                            .clickable { sel = i }
                    ) {
                        if (i == sel) {
                            Icon(
                                Icons.Filled.CheckCircle, null, tint = Color(0xFF22C55E),
                                modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp).size(20.dp)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .padding(horizontal = 28.dp)
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFFFF2D87), Color(0xFFFFB300))))
                    .clickable { onUse(sel) },
                contentAlignment = Alignment.Center
            ) {
                Text(tr("Use"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
private fun QuickItem(icon: ImageVector, tint: Color, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(60.dp).background(Card2, CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = tint, modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp)
    }
}

@Composable
fun QuickActions(onAll: () -> Unit, onRecent: () -> Unit, onMusic: () -> Unit, onStream: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        QuickItem(Icons.Filled.GridView, Color(0xFFFFB454), tr("All videos"), onAll)
        QuickItem(Icons.Filled.Schedule, Color(0xFF7BC97E), tr("Recent"), onRecent)
        QuickItem(Icons.Filled.MusicNote, Color(0xFFBA68C8), tr("Music"), onMusic)
        QuickItem(Icons.Filled.Public, Color(0xFF4F9BFF), tr("Stream"), onStream)
    }
}

@Composable
fun ContinueRow(list: List<ResumeItem>, loader: ImageLoader, onClick: (ResumeItem) -> Unit) {
    if (list.isNotEmpty()) {
        Column {
            SectionTitle(tr("Continue watching"))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list.size) { i ->
                    val r = list[i]
                    Column(Modifier.width(176.dp).clickable { onClick(r) }) {
                        Box(Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(12.dp))) {
                            VideoThumb(r.video, loader, Modifier.fillMaxSize(), showDuration = true)
                            Box(
                                Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp)
                                    .background(Color(0x66000000))
                            )
                            Box(
                                Modifier.align(Alignment.BottomStart).fillMaxWidth(r.frac.coerceIn(0f, 1f)).height(4.dp)
                                    .background(Blue)
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(r.video.title, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun OptionPills(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Text(
                label,
                color = if (sel) Color.White else Grey,
                fontSize = 14.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) Blue else Card2)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun ViewDialog(opts: ViewOpts, onChange: (ViewOpts) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(tr("View & sort")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(tr("View mode"), color = Grey, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                OptionPills(listOf(tr("List"), tr("Grid")), if (opts.grid) 1 else 0) { onChange(opts.copy(grid = it == 1)) }
                if (opts.grid) {
                    Text(tr("Grid columns"), color = Grey, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                    OptionPills(listOf("2", "3"), if (opts.cols == 3) 1 else 0) { onChange(opts.copy(cols = if (it == 1) 3 else 2)) }
                }
                Text(tr("Sort by"), color = Grey, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                OptionPills(listOf(tr("Name"), tr("Date"), tr("Size"), tr("Length")), opts.sortKey) { onChange(opts.copy(sortKey = it)) }
                Text(tr("Order"), color = Grey, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                OptionPills(listOf(tr("Ascending"), tr("Descending")), if (opts.desc) 1 else 0) { onChange(opts.copy(desc = it == 1)) }
                Spacer(Modifier.height(10.dp))
                SettingRow(tr("Show duration"), opts.showDuration) { onChange(opts.copy(showDuration = it)) }
                SettingRow(tr("Show file size"), opts.showSize) { onChange(opts.copy(showSize = it)) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Done")) } }
    )
}

@Composable
fun MusicSleepDialog(active: Boolean, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(tr("Sleep timer")) },
        text = {
            Column {
                listOf(15, 30, 45, 60, 90).forEach { m ->
                    Text(
                        trMinutes(m),
                        modifier = Modifier.fillMaxWidth().clickable { onPick(m) }.padding(vertical = 12.dp)
                    )
                }
                Text(
                    tr("End of this song"),
                    modifier = Modifier.fillMaxWidth().clickable { onPick(-1) }.padding(vertical = 12.dp)
                )
                if (active) {
                    Text(
                        tr("Turn off timer"),
                        color = Blue,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(0) }.padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } }
    )
}

@Composable
fun LyricsEditDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(tr("Lyrics")) },
        text = {
            OutlinedTextField(value = t, onValueChange = { t = it }, modifier = Modifier.fillMaxWidth().height(300.dp))
        },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onSave(t) }) { Text(tr("Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } }
    )
}

@Composable
fun LyricsPanel(song: Song, position: Long, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var text by remember(song.id) { mutableStateOf(LyricsStore.load(context, song)) }
    var editing by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val t = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                if (!t.isNullOrBlank()) {
                    LyricsStore.save(context, song, t)
                    text = t
                }
            } catch (e: Exception) {
                Toast.makeText(context, tr("Could not read the file"), Toast.LENGTH_SHORT).show()
            }
        }
    }
    val current = text
    val lines = remember(current) { if (current == null) emptyList() else parseLrc(current) }
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Card2.copy(alpha = 0.6f)).padding(12.dp)) {
        if (current == null) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(tr("No lyrics yet"), color = Grey)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { editing = true }) { Text(tr("Paste lyrics")) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(tr("Open lyrics file (.lrc or .txt)")) }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { editing = true }) { Text(tr("Edit")) }
                TextButton(onClick = {
                    LyricsStore.delete(context, song)
                    text = null
                }) { Text(tr("Remove lyrics")) }
            }
            if (lines.isNotEmpty()) {
                val listState = rememberLazyListState()
                val idx = lines.indexOfLast { it.timeMs <= position }
                LaunchedEffect(idx) {
                    if (idx >= 0) listState.animateScrollToItem((idx - 2).coerceAtLeast(0))
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                    items(lines.size) { i ->
                        val active = i == idx
                        Text(
                            lines[i].text,
                            fontSize = if (active) 20.sp else 16.sp,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            color = if (active) OnBg else Grey,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        )
                    }
                }
            } else {
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Text(current, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
    if (editing) {
        LyricsEditDialog(
            initial = current ?: "",
            onDismiss = { editing = false },
            onSave = { t ->
                LyricsStore.save(context, song, t)
                text = t
                editing = false
            }
        )
    }
}

@Composable
fun LanguageDialog(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardColor,
        title = { Text(tr("Language")) },
        text = {
            Column {
                listOf("en" to "English", "am" to "አማርኛ").forEach { (code, name) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(code) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(name, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        if (code == current) Icon(Icons.Filled.CheckCircle, null, tint = Blue)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } }
    )
}
