package com.example.myplayer

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Blue = Color(0xFF3B82F6)
val Grey = Color(0xFF9AA4B2)
val CardColor = Color(0xFF141B2B)

@Composable
fun KnxoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Color.Black,
            surface = CardColor,
            surfaceVariant = CardColor,
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { KnxoTheme { App(tick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

private val mediaPerms =
    if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

private val askPerms =
    if (Build.VERSION.SDK_INT >= 33) mediaPerms + Manifest.permission.POST_NOTIFICATIONS else mediaPerms

private fun hasMedia(c: Context) =
    mediaPerms.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

fun Context.playVideos(list: List<Video>, index: Int, pos: Long = 0L) {
    startActivity(
        Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("uris", ArrayList(list.map { it.uri.toString() }))
            .putStringArrayListExtra("titles", ArrayList(list.map { it.title }))
            .putExtra("index", index)
            .putExtra("pos", pos)
            .putExtra("durs", list.map { it.durationMs }.toLongArray())
    )
}

private fun Song.toItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(albumArtUri(albumId))
                .build()
        )
        .build()

private val tabNames = listOf("Videos", "Songs", "Artists", "Albums", "Playlists", "Favorites")

@Composable
fun App(tick: Int) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lib = remember { Library(context) }

    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(hasMedia(context)) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var detail by remember { mutableStateOf<String?>(null) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showAbout by remember { mutableStateOf(false) }
    var crashTrace by remember {
        mutableStateOf(context.getSharedPreferences("knxo_crash", Context.MODE_PRIVATE).getString("trace", null))
    }
    var showStream by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableIntStateOf(0) }

    var favs by remember { mutableStateOf(lib.favorites()) }
    var playlistsMap by remember { mutableStateOf(lib.playlists()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }

    var transfer by remember { mutableStateOf<String?>(null) }
    var newFolder by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var pickPlaylist by remember { mutableStateOf<List<String>?>(null) }
    var newPlaylistFor by remember { mutableStateOf<List<String>?>(null) }

    var controller by remember { mutableStateOf<MediaController?>(null) }
    var nowMediaId by remember { mutableStateOf<String?>(null) }
    var nowTitle by remember { mutableStateOf<String?>(null) }
    var nowArtist by remember { mutableStateOf("") }
    var nowPlaying by remember { mutableStateOf(false) }
    var showNowPlaying by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_LONG).show()

    fun openEqualizer() {
        val i = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
            .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
            .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0)
            .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
        try {
            context.startActivity(i)
        } catch (e: Exception) {
            toast("No system equalizer found on this phone")
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMedia(context)
    }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        selected = emptySet()
        reloadKey++
    }
    val loader = remember { ImageLoader.Builder(context).components { add(VideoFrameDecoder.Factory()) }.build() }
    val prefs = remember { context.getSharedPreferences("knxo", Context.MODE_PRIVATE) }
    val lastUri = remember(tick) { prefs.getString("uri", null) }
    val lastTitle = remember(tick) { prefs.getString("title", "") ?: "" }
    val lastPos = remember(tick) { prefs.getLong("pos", 0L) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(askPerms) }
    LaunchedEffect(granted, tick, reloadKey) {
        if (granted) {
            videos = withContext(Dispatchers.IO) { loadVideos(context) }
            songs = withContext(Dispatchers.IO) { loadSongs(context) }
        }
    }
    LaunchedEffect(searching) { if (searching) focus.requestFocus() }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, MusicService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                        nowTitle = mediaMetadata.title?.toString()
                        nowArtist = mediaMetadata.artist?.toString() ?: ""
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        nowMediaId = mediaItem?.mediaId
                    }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { nowPlaying = isPlaying }
                })
                nowMediaId = c.currentMediaItem?.mediaId
                nowTitle = c.mediaMetadata.title?.toString()
                nowArtist = c.mediaMetadata.artist?.toString() ?: ""
                nowPlaying = c.isPlaying
            } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(context))
        onDispose { MediaController.releaseFuture(future) }
    }

    fun playSongs(list: List<Song>, index: Int, shuffle: Boolean = false) {
        controller?.let { c ->
            c.shuffleModeEnabled = shuffle
            c.setMediaItems(list.map { it.toItem() }, index, 0L)
            c.prepare()
            c.play()
        }
    }

    fun toggleSel(key: String) {
        selected = if (key in selected) selected - key else selected + key
    }

    fun toggleFav(key: String) {
        favs = if (key in favs) favs - key else favs + key
        lib.saveFavorites(favs)
    }

    fun savePlaylists(m: Map<String, List<String>>) {
        playlistsMap = m
        lib.savePlaylists(m)
    }

    fun addToPlaylist(uris: List<String>) {
        if (uris.isEmpty()) return
        if (playlistsMap.isEmpty()) newPlaylistFor = uris else pickPlaylist = uris
    }

    fun selectedVideos() = videos.filter { it.uri.toString() in selected }
    fun selectedSongs() = songs.filter { it.uri.toString() in selected }
    fun selectedRefs(): List<MediaRef> =
        selectedVideos().map { MediaRef(it.uri, it.title, it.mime, true) } +
            selectedSongs().map { MediaRef(it.uri, it.fileName, it.mime, false) }

    fun startTransfer(kind: String) {
        val refs = selectedRefs()
        if (refs.isEmpty()) return
        if (refs.any { it.isVideo } && refs.any { !it.isVideo }) {
            toast("Select only videos or only songs")
            return
        }
        if (Build.VERSION.SDK_INT < 29) {
            toast("Copy and move need Android 10 or newer")
            return
        }
        if (kind == "move" && Build.VERSION.SDK_INT < 30) {
            toast("Move needs Android 11 or newer. Use Copy instead.")
            return
        }
        transfer = kind
    }

    fun doTransfer(relPath: String) {
        val kind = transfer ?: return
        transfer = null
        newFolder = false
        val refs = selectedRefs()
        scope.launch {
            working = true
            val done = withContext(Dispatchers.IO) { refs.filter { copyMedia(context, it, relPath) } }
            working = false
            toast("${done.size} of ${refs.size} copied")
            if (kind == "move" && done.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
                try {
                    val sender = MediaStore.createDeleteRequest(context.contentResolver, done.map { it.uri }).intentSender
                    deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                } catch (e: Exception) {
                    toast("Copied, but the originals could not be removed")
                    selected = emptySet()
                    reloadKey++
                }
            } else {
                selected = emptySet()
                reloadKey++
            }
        }
    }

    BackHandler(enabled = detail != null) { detail = null }
    BackHandler(enabled = searching) { searching = false; query = "" }
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }
    BackHandler(enabled = showNowPlaying) { showNowPlaying = false }

    val q = query.trim()
    val recents = remember(tick, reloadKey, detail) { lib.recents() }
    val resumeItems = remember(tick, reloadKey, videos) {
        lib.recents().mapNotNull { u ->
            val v = videos.find { it.uri.toString() == u } ?: return@mapNotNull null
            val pos = lib.getPos(u)
            val frac = if (v.durationMs > 0) pos.toFloat() / v.durationMs else 0f
            if (pos > 5000 && frac < 0.95f) ResumeItem(v, pos, frac) else null
        }.take(10)
    }
    val section = when (tab) {
        0 -> 0
        1, 2, 3 -> 1
        else -> 2
    }
    val nowSong = songs.find { it.id.toString() == nowMediaId }
    val inPlaylist = tab == 4 && detail != null
    val env = RowEnv(
        loader = loader,
        selected = selected,
        favs = favs,
        toggleSel = { toggleSel(it) },
        toggleFav = { toggleFav(it) },
        share = { uri, mime -> context.shareMedia(uri, mime) },
        addToPlaylist = { addToPlaylist(listOf(it)) }
    )

    if (showAbout) AboutDialog { showAbout = false }
    crashTrace?.let { trace ->
        AlertDialog(
            onDismissRequest = {},
            containerColor = CardColor,
            title = { Text("Knxo Play closed unexpectedly") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Please share this report with the developer so the problem can be fixed.", fontSize = 13.sp, color = Grey)
                    Spacer(Modifier.height(8.dp))
                    Text(trace.take(1500), fontSize = 10.sp, lineHeight = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, trace)
                    }
                    context.startActivity(Intent.createChooser(send, "Share report"))
                }) { Text("Share") }
            },
            dismissButton = {
                TextButton(onClick = {
                    context.getSharedPreferences("knxo_crash", Context.MODE_PRIVATE).edit().remove("trace").apply()
                    crashTrace = null
                }) { Text("Close") }
            }
        )
    }
    if (showSettings) SettingsDialog(lib) { showSettings = false }
    if (showStream) {
        TextInputDialog(
            title = "Stream URL (http, https, rtsp)",
            confirm = "Play",
            onDismiss = { showStream = false },
            onConfirm = { url ->
                showStream = false
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("rtsp://")) {
                    val name = url.substringAfterLast('/').ifBlank { url }
                    context.playVideos(listOf(Video(0, name, 0, Uri.parse(url), "", 0)), 0)
                } else {
                    toast("Enter a valid link starting with http, https or rtsp")
                }
            }
        )
    }
    if (working) WorkingDialog()

    if (transfer != null && !newFolder) {
        val isVideo = selectedVideos().isNotEmpty()
        val allowed =
            if (isVideo) listOf("Movies/", "DCIM/", "Pictures/")
            else listOf("Music/", "Podcasts/", "Recordings/", "Audiobooks/")
        val pool = if (isVideo) videos.map { it.relPath } else songs.map { it.relPath }
        val dests = pool.filter { p -> p.isNotBlank() && allowed.any { p.startsWith(it) } }.distinct().sorted()
        ChoiceDialog(
            title = if (transfer == "move") "Move to" else "Copy to",
            options = dests,
            extraLabel = "+ New folder",
            onPick = { doTransfer(it) },
            onExtra = { newFolder = true },
            onDismiss = { transfer = null }
        )
    }
    if (newFolder) {
        TextInputDialog(
            title = "New folder",
            confirm = "Create",
            onDismiss = { newFolder = false; transfer = null },
            onConfirm = { raw ->
                val name = raw.replace("/", "").replace("\\", "").trim()
                if (name.isNotEmpty()) {
                    val base = if (selectedVideos().isNotEmpty()) "Movies/" else "Music/"
                    doTransfer("$base$name/")
                }
            }
        )
    }
    pickPlaylist?.let { uris ->
        ChoiceDialog(
            title = "Add to playlist",
            options = playlistsMap.keys.toList(),
            extraLabel = "+ New playlist",
            onPick = { name ->
                savePlaylists(playlistsMap + (name to ((playlistsMap[name] ?: emptyList()) + uris).distinct()))
                pickPlaylist = null
                selected = emptySet()
                toast("Added to $name")
            },
            onExtra = { newPlaylistFor = uris; pickPlaylist = null },
            onDismiss = { pickPlaylist = null }
        )
    }
    newPlaylistFor?.let { uris ->
        TextInputDialog(
            title = "New playlist",
            confirm = "Create",
            onDismiss = { newPlaylistFor = null },
            onConfirm = { name ->
                savePlaylists(playlistsMap + (name to ((playlistsMap[name] ?: emptyList()) + uris).distinct()))
                newPlaylistFor = null
                selected = emptySet()
            }
        )
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101A30), Color(0xFF05070C), Color.Black)))
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = Color.White,
            bottomBar = {
                Column {
                    if (nowTitle != null) {
                        MiniPlayer(
                            song = nowSong,
                            title = nowTitle ?: "",
                            artist = nowArtist,
                            playing = nowPlaying,
                            onOpen = { showNowPlaying = true },
                            onPrev = { controller?.seekToPreviousMediaItem() },
                            onToggle = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                            onNext = { controller?.seekToNextMediaItem() }
                        )
                    }
                    NavigationBar(containerColor = Color(0xFF0B1220), contentColor = Color.White) {
                        listOf(
                            Triple("Video", Icons.Filled.VideoLibrary, 0),
                            Triple("Music", Icons.Filled.MusicNote, 1),
                            Triple("Playlist", Icons.Filled.LibraryMusic, 4)
                        ).forEachIndexed { idx, (label, icon, target) ->
                            NavigationBarItem(
                                selected = section == idx,
                                onClick = {
                                    if (section != idx) tab = target
                                    detail = null
                                    selected = emptySet()
                                    searching = false
                                    query = ""
                                },
                                icon = { Icon(icon, label) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blue,
                                    selectedTextColor = Blue,
                                    indicatorColor = Color(0xFF1B2640),
                                    unselectedIconColor = Grey,
                                    unselectedTextColor = Grey
                                )
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                if (lastUri != null && tab == 0 && detail == null && selected.isEmpty()) {
                    FloatingActionButton(
                        onClick = {
                            context.playVideos(listOf(Video(0, lastTitle, 0, Uri.parse(lastUri), "", 0)), 0, lastPos)
                        },
                        shape = CircleShape,
                        containerColor = Blue,
                        contentColor = Color.White
                    ) { Icon(Icons.Filled.PlayArrow, contentDescription = "Continue") }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    !granted -> Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("ፋይሎችን ለማየት ፈቃድ ያስፈልጋል")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { permLauncher.launch(askPerms) }) { Text("Allow access") }
                    }
                    detail != null && tab == 0 -> Column(Modifier.fillMaxSize()) {
                        DetailHeader(detail!!, onBack = { detail = null })
                        val vlist = when (detail) {
                            "All videos" -> videos
                            "Recent" -> recents.mapNotNull { u -> videos.find { it.uri.toString() == u } }
                            else -> videos.filter { it.folder == detail }
                        }
                        VideoList(vlist, env)
                    }
                    detail != null -> {
                        val list: List<Song> = when (tab) {
                            2 -> songs.filter { it.artist == detail }
                            3 -> songs.filter { it.album == detail }
                            else -> (playlistsMap[detail] ?: emptyList()).mapNotNull { u ->
                                songs.find { it.uri.toString() == u }
                            }
                        }
                        Column(Modifier.fillMaxSize()) {
                            DetailHeader(
                                detail!!,
                                onBack = { detail = null },
                                trailing = {
                                    if (tab == 4) {
                                        IconButton(onClick = {
                                            savePlaylists(playlistsMap - detail!!)
                                            detail = null
                                        }) { Icon(Icons.Filled.Delete, "Delete playlist") }
                                    }
                                }
                            )
                            SongList(list, env, onPlay = { playSongs(list, it) })
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (searching) {
                                TextField(
                                    value = query,
                                    onValueChange = { query = it },
                                    singleLine = true,
                                    placeholder = { Text("Search") },
                                    shape = RoundedCornerShape(26.dp),
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = CardColor,
                                        unfocusedContainerColor = CardColor,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent
                                    ),
                                    modifier = Modifier.weight(1f).focusRequester(focus)
                                )
                                IconButton(onClick = { searching = false; query = "" }) { Icon(Icons.Filled.Close, "Close") }
                            } else {
                                Text(
                                    when (section) {
                                        0 -> "Knxo Play"
                                        1 -> "Music"
                                        else -> "Playlist"
                                    },
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Search") }
                                Box {
                                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                        DropdownMenuItem(text = { Text("Network stream") }, onClick = { menuOpen = false; showStream = true })
                                        DropdownMenuItem(text = { Text("Refresh") }, onClick = { menuOpen = false; reloadKey++ })
                                        DropdownMenuItem(text = { Text("Equalizer") }, onClick = { menuOpen = false; openEqualizer() })
                                        DropdownMenuItem(text = { Text("Settings") }, onClick = { menuOpen = false; showSettings = true })
                                        DropdownMenuItem(text = { Text("About") }, onClick = { menuOpen = false; showAbout = true })
                                    }
                                }
                            }
                        }
                        val subTabs: List<Int> = when (tab) {
                            1, 2, 3 -> listOf(1, 2, 3)
                            4, 5 -> listOf(4, 5)
                            else -> emptyList()
                        }
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            tabNames.forEachIndexed { i, t ->
                                if (i !in subTabs) return@forEachIndexed
                                val sel = tab == i
                                Text(
                                    t,
                                    color = if (sel) Color.White else Grey,
                                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (sel) Blue else CardColor)
                                        .clickable { tab = i; detail = null; selected = emptySet() }
                                        .padding(horizontal = 20.dp, vertical = 9.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        when {
                            q.isNotEmpty() && tab == 0 ->
                                VideoList(videos.filter { it.title.contains(q, true) }, env)
                            q.isNotEmpty() -> {
                                val found = songs.filter {
                                    it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
                                }
                                SongList(found, env, onPlay = { playSongs(found, it) })
                            }
                            tab == 0 -> FolderList(
                                videos, loader,
                                header = {
                                    Column {
                                        QuickActions(
                                            onAll = { detail = "All videos" },
                                            onRecent = { detail = "Recent" },
                                            onMusic = { tab = 1; detail = null },
                                            onStream = { showStream = true }
                                        )
                                        ContinueRow(resumeItems, loader) { r ->
                                            context.playVideos(listOf(r.video), 0, r.posMs)
                                        }
                                    }
                                },
                                onPlayAll = { name ->
                                    val l = videos.filter { it.folder == name }
                                    if (l.isNotEmpty()) context.playVideos(l, 0)
                                }
                            ) { detail = it }
                            tab == 1 -> SongList(songs, env, onPlay = { playSongs(songs, it) }, header = {
                                if (songs.isNotEmpty()) {
                                    Row(
                                        Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Button(onClick = { playSongs(songs, 0) }) {
                                            Icon(Icons.Filled.PlayArrow, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Play all")
                                        }
                                        OutlinedButton(onClick = { playSongs(songs, Random.nextInt(songs.size), true) }) {
                                            Icon(Icons.Filled.Shuffle, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Shuffle")
                                        }
                                    }
                                }
                            })
                            tab == 2 -> GroupList(
                                songs.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() },
                                Icons.Filled.Person
                            ) { detail = it }
                            tab == 3 -> GroupList(
                                songs.groupBy { it.album }.toList().sortedBy { it.first.lowercase() },
                                Icons.Filled.Album
                            ) { detail = it }
                            tab == 4 -> GroupList(
                                playlistsMap.map { (n, uris) -> n to uris.mapNotNull { u -> songs.find { it.uri.toString() == u } } },
                                Icons.Filled.MusicNote,
                                header = {
                                    Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                                        Button(onClick = { newPlaylistFor = emptyList() }) {
                                            Icon(Icons.Filled.Add, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("New playlist")
                                        }
                                    }
                                }
                            ) { detail = it }
                            else -> {
                                val favSongs = songs.filter { it.uri.toString() in favs }
                                FavoritesList(
                                    videos.filter { it.uri.toString() in favs },
                                    favSongs, env,
                                    onPlaySong = { playSongs(favSongs, it) }
                                )
                            }
                        }
                    }
                }

                if (selected.isNotEmpty()) {
                    SelectionBar(
                        count = selected.size,
                        allFav = selected.all { it in favs },
                        inPlaylist = inPlaylist,
                        hasSongs = selectedSongs().isNotEmpty(),
                        modifier = Modifier.align(Alignment.TopStart),
                        onClose = { selected = emptySet() },
                        onShare = {
                            val vs = selectedVideos()
                            val ss = selectedSongs()
                            val mime = when {
                                vs.isNotEmpty() && ss.isNotEmpty() -> "*/*"
                                vs.isNotEmpty() -> "video/*"
                                else -> "audio/*"
                            }
                            context.shareUris(vs.map { it.uri } + ss.map { it.uri }, mime)
                            selected = emptySet()
                        },
                        onFav = {
                            val all = selected.all { it in favs }
                            favs = if (all) favs - selected else favs + selected
                            lib.saveFavorites(favs)
                            selected = emptySet()
                        },
                        onMove = { startTransfer("move") },
                        onCopy = { startTransfer("copy") },
                        onAddPlaylist = { addToPlaylist(selectedSongs().map { it.uri.toString() }) },
                        onRemoveFromPlaylist = {
                            val name = detail
                            if (name != null) {
                                savePlaylists(playlistsMap + (name to (playlistsMap[name] ?: emptyList()).filter { it !in selected }))
                            }
                            selected = emptySet()
                        }
                    )
                }
            }
        }

        val c = controller
        if (showNowPlaying && c != null) {
            NowPlayingScreen(
                c = c,
                song = nowSong,
                title = nowTitle ?: "",
                artist = nowArtist,
                playing = nowPlaying,
                onClose = { showNowPlaying = false }
            )
        }
    }
}
