package com.example.myplayer

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Video(val id: Long, val title: String, val durationMs: Long, val uri: Uri)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) {
                    VideoListScreen { video ->
                        startActivity(Intent(this, PlayerActivity::class.java).setData(video.uri))
                    }
                }
            }
        }
    }
}

private val permission =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
fun VideoListScreen(onClick: (Video) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    LaunchedEffect(Unit) { launcher.launch(permission) }
    LaunchedEffect(granted) { if (granted) videos = loadVideos(context) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Knxo Play", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(16.dp))
        if (!granted) {
            Text("ቪዲዮዎችን ለማየት ፈቃድ ያስፈልጋል", modifier = Modifier.padding(16.dp))
        } else {
            LazyColumn {
                items(videos, key = { it.id }) { v ->
                    ListItem(
                        headlineContent = { Text(v.title, maxLines = 1) },
                        supportingContent = { Text(formatDuration(v.durationMs)) },
                        modifier = Modifier.clickable { onClick(v) }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

fun loadVideos(context: Context): List<Video> {
    val list = mutableListOf<Video>()
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION
    )
    context.contentResolver.query(
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null,
        "${MediaStore.Video.Media.DATE_ADDED} DESC"
    )?.use { c ->
        val id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val name = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        val dur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
        while (c.moveToNext()) {
            val vid = c.getLong(id)
            list += Video(
                vid, c.getString(name) ?: "Video", c.getLong(dur),
                Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, vid.toString())
            )
        }
    }
    return list
}

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}
