package com.example.myplayer

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Blue = Color(0xFF3B82F6)
val Grey = Color(0xFF9AA4B2)

@Composable
fun KnxoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Color.Black,
            surface = Color.Black,
            surfaceVariant = Color(0xFF1C2230),
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KnxoTheme { App(tick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

private val mediaPerms =
    if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

private val askPerms =
    if (Build.VERSION.SDK_INT >= 33) mediaPerms + Manifest.permission.POST_NOTIFICATIONS else mediaPerms

private fun hasMedia(c: Context) =
    mediaPerms.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

fun Context.playVideos(list: List<Video>, index: Int, pos: Long = 0L) {
    startActivity(
        Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("uris", ArrayList(list.map { it.uri.toString() }))
            .putStringArrayListExtra("titles", ArrayList(list.map { it.title }))
            .putExtra("index", index)
            .putExtra("pos", pos)
    )
}

private fun Song.toItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(albumArtUri(albumId))
                .build()
        )
        .build()

@Composable
fun App(tick: Int) {
    val context = LocalContext.current
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(hasMedia(context)) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var detail by remember { mutableStateOf<String?>(null) }

    var controller by remember { mutableStateOf<MediaController?>(null) }
    var nowTitle by remember { mutableStateOf<String?>(null) }
    var nowArtist by remember { mutableStateOf("") }
    var nowPlaying by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMedia(context)
    }
    val loader = remember { ImageLoader.Builder(context).components { add(VideoFrameDecoder.Factory()) }.build() }
    val prefs = remember { context.getSharedPreferences("knxo", Context.MODE_PRIVATE) }
    val lastUri = remember(tick) { prefs.getString("uri", null) }
    val lastTitle = remember(tick) { prefs.getString("title", "") ?: "" }
    val lastPos = remember(tick) { prefs.getLong("pos", 0L) }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(askPerms) }
    LaunchedEffect(granted, tick) {
        if (granted) {
            videos = withContext(Dispatchers.IO) { loadVideos(context) }
            songs = withContext(Dispatchers.IO) { loadSongs(context) }
        }
    }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, MusicService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                        nowTitle = mediaMetadata.title?.toString()
                        nowArtist = mediaMetadata.artist?.toString() ?: ""
                    }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { nowPlaying = isPlaying }
                })
                nowTitle = c.mediaMetadata.title?.toString()
                nowArtist = c.mediaMetadata.artist?.toString() ?: ""
                nowPlaying = c.isPlaying
            } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(context))
        onDispose { MediaController.releaseFuture(future) }
    }

    fun playSongs(list: List<Song>, index: Int) {
        controller?.let { c ->
            c.setMediaItems(list.map { it.toItem() }, index, 0L)
            c.prepare()
            c.play()
        }
    }

    BackHandler(enabled = detail != null) { detail = null }
    val tabs = listOf("Videos", "Songs", "Artists", "Albums")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (nowTitle != null) {
                MiniPlayer(
                    title = nowTitle ?: "",
                    artist = nowArtist,
                    playing = nowPlaying,
                    onToggle = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                    onNext = { controller?.seekToNextMediaItem() }
                )
            }
        },
        floatingActionButton = {
            if (lastUri != null && tab == 0 && detail == null) {
                FloatingActionButton(
                    onClick = {
                        context.playVideos(listOf(Video(0, lastTitle, 0, Uri.parse(lastUri), "", 0)), 0, lastPos)
                    },
                    shape = CircleShape,
                    containerColor = Blue,
                    contentColor = Color.White
                ) { Icon(Icons.Filled.PlayArrow, contentDescription = "Continue") }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                !granted -> Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("ፋይሎችን ለማየት ፈቃድ ያስፈልጋል")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { launcher.launch(askPerms) }) { Text("Allow access") }
                }
                detail != null && tab == 0 -> FolderVideos(
                    name = detail!!,
                    list = videos.filter { it.folder == detail },
                    loader = loader,
                    onBack = { detail = null }
                )
                detail != null -> {
                    val list = if (tab == 2) songs.filter { it.artist == detail } else songs.filter { it.album == detail }
                    SongsDetail(detail!!, list, onBack = { detail = null }, onPlay = { playSongs(list, it) })
                }
                else -> Column(Modifier.fillMaxSize()) {
                    Text(
                        "Knxo Play",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 12.dp)
                    )
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        tabs.forEachIndexed { i, t ->
                            FilterChip(selected = tab == i, onClick = { tab = i; detail = null }, label = { Text(t) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    when (tab) {
                        0 -> FolderList(videos) { detail = it }
                        1 -> SongsList(songs) { playSongs(songs, it) }
                        2 -> GroupList(
                            songs.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() },
                            Icons.Filled.Person
                        ) { detail = it }
                        else -> GroupList(
                            songs.groupBy { it.album }.toList().sortedBy { it.first.lowercase() },
                            Icons.Filled.Album
                        ) { detail = it }
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(title: String, artist: String, playing: Boolean, onToggle: () -> Unit, onNext: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.MusicNote, null, tint = Blue)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (artist.isNotEmpty()) Text(artist, fontSize = 12.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onToggle) {
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause")
        }
        IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, "Next") }
    }
}

@Composable
fun SongArt(song: Song, size: Dp) {
    val context = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, song.id) {
        value = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    context.contentResolver.loadThumbnail(song.uri, Size(256, 256), null).asImageBitmap()
                } else {
                    context.contentResolver.openInputStream(albumArtUri(song.albumId))?.use {
                        BitmapFactory.decodeStream(it)?.asImageBitmap()
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1C2230)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.MusicNote, null, tint = Color(0xFF6B778C), modifier = Modifier.size(size / 2))
    }
}

@Composable
fun SongsList(songs: List<Song>, onPlay: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(songs.size, key = { songs[it].id }) { i ->
            val s = songs[i]
            Row(
                Modifier.fillMaxWidth().clickable { onPlay(i) }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SongArt(s, 64.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(s.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(s.artist, fontSize = 13.sp, color = Grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun SongsDetail(name: String, list: List<Song>, onBack: () -> Unit, onPlay: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text(name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        SongsList(list, onPlay)
    }
}

@Composable
fun GroupList(groups: List<Pair<String, List<Song>>>, icon: ImageVector, onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(groups, key = { it.first }) { (name, list) ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(name) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(60.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = Color(0xFF8FA3C0), modifier = Modifier.size(32.dp)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(name, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (list.size == 1) "1 song" else "${list.size} songs", fontSize = 14.sp, color = Grey)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun FolderList(videos: List<Video>, onOpen: (String) -> Unit) {
    val folders = remember(videos) { videos.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() } }
    LazyColumn(Modifier.fillMaxSize()) {
        items(folders, key = { it.first }) { (name, list) ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(name) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(60.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Folder, null, tint = Color(0xFF8FA3C0), modifier = Modifier.size(34.dp)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(name, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (list.size == 1) "1 video" else "${list.size} videos", fontSize = 14.sp, color = Grey)
                }
            }
        }
        item { Spacer(Modifier.height(96.dp)) }
    }
}

@Composable
fun FolderVideos(name: String, list: List<Video>, loader: ImageLoader, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text(name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(list.size, key = { list[it].id }) { i ->
                val v = list[i]
                Row(
                    Modifier.fillMaxWidth().clickable { context.playVideos(list, i) }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(128.dp).height(76.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF1C2230))) {
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(v.uri).videoFrameMillis(1000).build(),
                            imageLoader = loader,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Text(
                            formatDuration(v.durationMs),
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(v.title, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        Text(formatSize(v.sizeBytes), fontSize = 13.sp, color = Grey)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
