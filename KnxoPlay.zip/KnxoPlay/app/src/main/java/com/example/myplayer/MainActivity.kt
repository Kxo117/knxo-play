@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.myplayer

import androidx.compose.material.icons.filled.Public
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.foundation.combinedClickable
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat
import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun KnxoTheme(content: @Composable () -> Unit) {
    val t = KnxoColors.theme
    val scheme = if (t.light) {
        lightColorScheme(
            primary = t.accent, background = t.bgBottom, surface = t.card, surfaceVariant = t.card,
            onSurface = t.onBg, onBackground = t.onBg, onSurfaceVariant = t.onBg
        )
    } else {
        darkColorScheme(
            primary = t.accent, background = t.bgBottom, surface = t.card, surfaceVariant = t.card,
            onSurface = t.onBg, onBackground = t.onBg, onSurfaceVariant = t.onBg
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private var stopTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadTheme(this)
        loadLang(this)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { KnxoTheme { App(tick, stopTick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }

    override fun onStop() {
        super.onStop()
        if (PrivateGate.skipLock) PrivateGate.skipLock = false else stopTick++
    }
}

private val mediaPerms =
    if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

private val askPerms =
    if (Build.VERSION.SDK_INT >= 33) mediaPerms + Manifest.permission.POST_NOTIFICATIONS else mediaPerms

private fun hasMedia(c: Context) =
    mediaPerms.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

fun Context.playVideos(list: List<Video>, index: Int, pos: Long = 0L) {
    startActivity(
        Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("uris", ArrayList(list.map { it.uri.toString() }))
            .putStringArrayListExtra("titles", ArrayList(list.map { it.title }))
            .putExtra("index", index)
            .putExtra("pos", pos)
            .putExtra("durs", list.map { it.durationMs }.toLongArray())
    )
}

private fun Song.toItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(albumArtUri(albumId))
                .build()
        )
        .build()

private val tabNames: List<String> get() = listOf(tr("Videos"), tr("Songs"), tr("Artists"), tr("Albums"), tr("Playlists"), tr("Favorites"))

@Composable
fun App(tick: Int, stopTick: Int = 0) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lib = remember { Library(context) }

    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(hasMedia(context)) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var detail by remember { mutableStateOf<String?>(null) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var crashTrace by remember {
        mutableStateOf(context.getSharedPreferences("knxo_crash", Context.MODE_PRIVATE).getString("trace", null))
    }
    var showStream by remember { mutableStateOf(false) }
    var showView by remember { mutableStateOf(false) }
    var viewOpts by remember { mutableStateOf(lib.viewOpts()) }
    var showSettings by remember { mutableStateOf(false) }
    var showTheme by remember { mutableStateOf(false) }
    var showShareApp by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    var showPrivate by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    var showLang by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableIntStateOf(0) }

    var favs by remember { mutableStateOf(lib.favorites()) }
    var playlistsMap by remember { mutableStateOf(lib.playlists()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }

    var transfer by remember { mutableStateOf<String?>(null) }
    var newFolder by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var pickPlaylist by remember { mutableStateOf<List<String>?>(null) }
    var newPlaylistFor by remember { mutableStateOf<List<String>?>(null) }

    var controller by remember { mutableStateOf<MediaController?>(null) }
    var nowMediaId by remember { mutableStateOf<String?>(null) }
    var nowTitle by remember { mutableStateOf<String?>(null) }
    var nowArtist by remember { mutableStateOf("") }
    var nowPlaying by remember { mutableStateOf(false) }
    var showNowPlaying by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_LONG).show()

    fun openEqualizer() {
        val i = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
            .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
            .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0)
            .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
        try {
            context.startActivity(i)
        } catch (e: Exception) {
            toast(tr("No system equalizer found on this phone"))
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMedia(context)
    }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        selected = emptySet()
        reloadKey++
    }
    val loader = remember { ImageLoader.Builder(context).components { add(VideoFrameDecoder.Factory()) }.build() }
    val prefs = remember { context.getSharedPreferences("knxo", Context.MODE_PRIVATE) }
    val browser = remember { BrowserState(context) }
    val lastUri = remember(tick) { prefs.getString("uri", null) }
    val lastTitle = remember(tick) { prefs.getString("title", "") ?: "" }
    val lastPos = remember(tick) { prefs.getLong("pos", 0L) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(askPerms) }
    LaunchedEffect(granted, tick, reloadKey) {
        if (granted) {
            videos = withContext(Dispatchers.IO) { loadVideos(context) }
            songs = withContext(Dispatchers.IO) { loadSongs(context) }
        }
    }
    LaunchedEffect(searching) { if (searching) focus.requestFocus() }

    DisposableEffect(Unit) {
        val appCtx = context.applicationContext
        val token = SessionToken(appCtx, ComponentName(appCtx, MusicService::class.java))
        val future = MediaController.Builder(appCtx, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                        nowTitle = mediaMetadata.title?.toString()
                        nowArtist = mediaMetadata.artist?.toString() ?: ""
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        nowMediaId = mediaItem?.mediaId
                    }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { nowPlaying = isPlaying }
                })
                nowMediaId = c.currentMediaItem?.mediaId
                nowTitle = c.mediaMetadata.title?.toString()
                nowArtist = c.mediaMetadata.artist?.toString() ?: ""
                nowPlaying = c.isPlaying
            } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            try {
                MediaController.releaseFuture(future)
            } catch (e: Exception) {
            }
        }
    }

    fun playSongs(list: List<Song>, index: Int, shuffle: Boolean = false) {
        controller?.let { c ->
            c.shuffleModeEnabled = shuffle
            c.setMediaItems(list.map { it.toItem() }, index, 0L)
            c.prepare()
            c.play()
        }
    }

    fun queueSongs(list: List<Song>, next: Boolean) {
        if (list.isEmpty()) return
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playSongs(list, 0)
            return
        }
        val items = list.map { it.toItem() }
        if (next) c.addMediaItems(c.currentMediaItemIndex + 1, items) else c.addMediaItems(items)
        toast(if (next) "Will play next" else "Added to queue")
    }

    fun toggleSel(key: String) {
        selected = if (key in selected) selected - key else selected + key
    }

    fun toggleFav(key: String) {
        favs = if (key in favs) favs - key else favs + key
        lib.saveFavorites(favs)
    }

    fun savePlaylists(m: Map<String, List<String>>) {
        playlistsMap = m
        lib.savePlaylists(m)
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                working = true
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val text = buildBackup(favs, playlistsMap, videos, songs)
                        context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                working = false
                toast(if (ok) tr("Backup saved") else tr("Could not save the backup"))
            }
        }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                working = true
                val text = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    } catch (e: Exception) {
                        null
                    }
                }
                val res = if (text == null) null else parseBackup(text, videos, songs)
                working = false
                if (res == null) {
                    toast(tr("This is not a valid Knxo Play backup file"))
                } else {
                    favs = favs + res.favs
                    lib.saveFavorites(favs)
                    val merged = LinkedHashMap(playlistsMap)
                    res.playlists.forEach { (n, l) -> merged[n] = ((merged[n] ?: emptyList()) + l).distinct() }
                    savePlaylists(merged)
                    toast(trRestored(res.favs.size, res.playlists.size, res.missing))
                }
            }
        }
    }

    fun shareBackup() {
        scope.launch {
            working = true
            val uri = withContext(Dispatchers.IO) { prepareBackupUri(context, buildBackup(favs, playlistsMap, videos, songs)) }
            working = false
            if (uri != null) context.shareBackupFile(uri) else toast(tr("Could not prepare the backup"))
        }
    }

    fun addToPlaylist(uris: List<String>) {
        if (uris.isEmpty()) return
        if (playlistsMap.isEmpty()) newPlaylistFor = uris else pickPlaylist = uris
    }

    fun selectedVideos() = videos.filter { it.uri.toString() in selected }
    fun selectedSongs() = songs.filter { it.uri.toString() in selected }
    fun selectedRefs(): List<MediaRef> =
        selectedVideos().map { MediaRef(it.uri, it.title, it.mime, true) } +
            selectedSongs().map { MediaRef(it.uri, it.fileName, it.mime, false) }

    fun startTransfer(kind: String) {
        val refs = selectedRefs()
        if (refs.isEmpty()) return
        if (refs.any { it.isVideo } && refs.any { !it.isVideo }) {
            toast(tr("Select only videos or only songs"))
            return
        }
        if (Build.VERSION.SDK_INT < 29) {
            toast(tr("Copy and move need Android 10 or newer"))
            return
        }
        if (kind == "move" && Build.VERSION.SDK_INT < 30) {
            toast(tr("Move needs Android 11 or newer. Use Copy instead."))
            return
        }
        transfer = kind
    }

    fun doTransfer(relPath: String) {
        val kind = transfer ?: return
        transfer = null
        newFolder = false
        val refs = selectedRefs()
        scope.launch {
            working = true
            val done = withContext(Dispatchers.IO) { refs.filter { copyMedia(context, it, relPath) } }
            working = false
            toast(trCopied(done.size, refs.size))
            if (kind == "move" && done.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
                try {
                    val sender = MediaStore.createDeleteRequest(context.contentResolver, done.map { it.uri }).intentSender
                    deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                } catch (e: Exception) {
                    toast(tr("Copied, but the originals could not be removed"))
                    selected = emptySet()
                    reloadKey++
                }
            } else {
                selected = emptySet()
                reloadKey++
            }
        }
    }

    LaunchedEffect(stopTick) { if (stopTick > 0) showPrivate = false }

    fun movePrivate() {
        val refs = selectedVideos().map { MediaRef(it.uri, it.title, it.mime, true) }
        if (refs.isEmpty()) {
            toast(tr("Select videos first"))
            return
        }
        if (!hasPin(lib)) {
            toast(tr("First set up your private folder: press and hold \"Knxo Play\" at the top."))
            return
        }
        if (Build.VERSION.SDK_INT < 30) {
            toast(tr("This needs Android 11 or newer"))
            return
        }
        scope.launch {
            working = true
            val done = withContext(Dispatchers.IO) { refs.filter { copyToPrivate(context, it) } }
            working = false
            toast(trMoved(done.size, refs.size))
            if (done.isNotEmpty()) {
                try {
                    val sender = MediaStore.createDeleteRequest(context.contentResolver, done.map { it.uri }).intentSender
                    deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                } catch (e: Exception) {
                    toast(tr("Could not remove the originals"))
                    selected = emptySet()
                    reloadKey++
                }
            } else {
                selected = emptySet()
            }
        }
    }

    DisposableEffect(Unit) { onDispose { browser.web.destroy() } }
    LaunchedEffect(tab) { if (tab == 6) browser.web.onResume() else browser.web.onPause() }
    BackHandler(enabled = tab == 6) {
        if (browser.started && browser.canBack) browser.web.goBack()
        else if (browser.started) browser.home()
        else tab = 0
    }
    BackHandler(enabled = detail != null) { detail = null }
    BackHandler(enabled = searching) { searching = false; query = "" }
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }
    BackHandler(enabled = showNowPlaying) { showNowPlaying = false }
    BackHandler(enabled = showSettings) { showSettings = false }
    BackHandler(enabled = showTheme) { showTheme = false }

    val appTheme = KnxoColors.theme
    LaunchedEffect(appTheme) {
        val act = context as? ComponentActivity
        if (act != null) {
            val bar = if (appTheme.light)
                SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
            else SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
            act.enableEdgeToEdge(statusBarStyle = bar, navigationBarStyle = bar)
        }
    }

    val q = query.trim()
    val songsView = remember(songs, viewOpts.sortKey, viewOpts.desc) { sortSongs(songs, viewOpts) }
    val recents = remember(tick, reloadKey, detail) { lib.recents() }
    val resumeItems = remember(tick, reloadKey, videos) {
        lib.recents().mapNotNull { u ->
            val v = videos.find { it.uri.toString() == u } ?: return@mapNotNull null
            val pos = lib.getPos(u)
            val frac = if (v.durationMs > 0) pos.toFloat() / v.durationMs else 0f
            if (pos > 5000 && frac < 0.95f) ResumeItem(v, pos, frac) else null
        }.take(10)
    }
    val section = when (tab) {
        0 -> 0
        1, 2, 3 -> 1
        4, 5 -> 2
        else -> 3
    }
    val nowSong = songs.find { it.id.toString() == nowMediaId }
    val inPlaylist = tab == 4 && detail != null
    val env = RowEnv(
        loader = loader,
        selected = selected,
        favs = favs,
        toggleSel = { toggleSel(it) },
        toggleFav = { toggleFav(it) },
        share = { uri, mime -> context.shareMedia(uri, mime) },
        addToPlaylist = { addToPlaylist(listOf(it)) },
        playNext = { key -> songs.find { it.uri.toString() == key }?.let { queueSongs(listOf(it), true) } },
        addToQueue = { key -> songs.find { it.uri.toString() == key }?.let { queueSongs(listOf(it), false) } }
    )

    crashTrace?.let { trace ->
        AlertDialog(
            onDismissRequest = {},
            containerColor = CardColor,
            title = { Text(tr("Knxo Play closed unexpectedly")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tr("Please share this report with the developer so the problem can be fixed."), fontSize = 13.sp, color = Grey)
                    Spacer(Modifier.height(8.dp))
                    Text(trace.take(1500), fontSize = 10.sp, lineHeight = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, trace)
                    }
                    context.startActivity(Intent.createChooser(send, tr("Share report")))
                }) { Text(tr("Share")) }
            },
            dismissButton = {
                TextButton(onClick = {
                    context.getSharedPreferences("knxo_crash", Context.MODE_PRIVATE).edit().remove("trace").apply()
                    crashTrace = null
                }) { Text(tr("Close")) }
            }
        )
    }
    if (showLang) {
        LanguageDialog(
            current = Lang.code,
            onPick = { code ->
                Lang.code = code
                lib.setIntPref("lang", if (code == "am") 1 else 0)
                showLang = false
            },
            onDismiss = { showLang = false }
        )
    }
    if (showView) ViewDialog(viewOpts, onChange = { viewOpts = it; lib.saveViewOpts(it) }, onDismiss = { showView = false })
    if (showBackup) {
        AlertDialog(
            onDismissRequest = { showBackup = false },
            containerColor = CardColor,
            title = { Text(tr("Back up")) },
            text = {
                Column {
                    Text(
                        tr("Favorites and playlists are saved by file name, so they can be restored even on a new phone."),
                        fontSize = 13.sp,
                        color = Grey
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        tr("Save to a file"),
                        modifier = Modifier.fillMaxWidth().clickable {
                            showBackup = false
                            val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                            saveLauncher.launch("KnxoPlay-backup-$stamp.json")
                        }.padding(vertical = 12.dp)
                    )
                    Text(
                        tr("Send (Telegram, Drive, ...)"),
                        modifier = Modifier.fillMaxWidth().clickable {
                            showBackup = false
                            shareBackup()
                        }.padding(vertical = 12.dp)
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showBackup = false }) { Text(tr("Cancel")) } }
        )
    }
    if (showShareApp) {
        AlertDialog(
            onDismissRequest = { showShareApp = false },
            containerColor = CardColor,
            title = { Text(tr("Share this app")) },
            text = {
                Column {
                    Text(
                        tr("Send app file (APK)"),
                        modifier = Modifier.fillMaxWidth().clickable {
                            showShareApp = false
                            scope.launch {
                                working = true
                                val apk = withContext(Dispatchers.IO) { prepareApkUri(context) }
                                working = false
                                if (apk != null) context.shareApk(apk) else toast(tr("Could not prepare the app file"))
                            }
                        }.padding(vertical = 12.dp)
                    )
                    Text(
                        tr("Send invite message"),
                        modifier = Modifier.fillMaxWidth().clickable {
                            showShareApp = false
                            context.shareInvite()
                        }.padding(vertical = 12.dp)
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showShareApp = false }) { Text(tr("Cancel")) } }
        )
    }
    if (showStream) {
        TextInputDialog(
            title = tr("Stream URL (http, https, rtsp)"),
            confirm = tr("Play"),
            onDismiss = { showStream = false },
            onConfirm = { url ->
                showStream = false
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("rtsp://")) {
                    val name = url.substringAfterLast('/').ifBlank { url }
                    context.playVideos(listOf(Video(0, name, 0, Uri.parse(url), "", 0)), 0)
                } else {
                    toast(tr("Enter a valid link starting with http, https or rtsp"))
                }
            }
        )
    }
    if (working) WorkingDialog()

    if (transfer != null && !newFolder) {
        val isVideo = selectedVideos().isNotEmpty()
        val allowed =
            if (isVideo) listOf("Movies/", "DCIM/", "Pictures/")
            else listOf("Music/", "Podcasts/", "Recordings/", "Audiobooks/")
        val pool = if (isVideo) videos.map { it.relPath } else songs.map { it.relPath }
        val dests = pool.filter { p -> p.isNotBlank() && allowed.any { p.startsWith(it) } }.distinct().sorted()
        ChoiceDialog(
            title = if (transfer == "move") tr("Move to") else tr("Copy to"),
            options = dests,
            extraLabel = tr("+ New folder"),
            onPick = { doTransfer(it) },
            onExtra = { newFolder = true },
            onDismiss = { transfer = null }
        )
    }
    if (newFolder) {
        TextInputDialog(
            title = tr("New folder"),
            confirm = tr("Create"),
            onDismiss = { newFolder = false; transfer = null },
            onConfirm = { raw ->
                val name = raw.replace("/", "").replace("\\", "").trim()
                if (name.isNotEmpty()) {
                    val base = if (selectedVideos().isNotEmpty()) "Movies/" else "Music/"
                    doTransfer("$base$name/")
                }
            }
        )
    }
    pickPlaylist?.let { uris ->
        ChoiceDialog(
            title = tr("Add to playlist"),
            options = playlistsMap.keys.toList(),
            extraLabel = tr("+ New playlist"),
            onPick = { name ->
                savePlaylists(playlistsMap + (name to ((playlistsMap[name] ?: emptyList()) + uris).distinct()))
                pickPlaylist = null
                selected = emptySet()
                toast(trAddedTo(name))
            },
            onExtra = { newPlaylistFor = uris; pickPlaylist = null },
            onDismiss = { pickPlaylist = null }
        )
    }
    newPlaylistFor?.let { uris ->
        TextInputDialog(
            title = tr("New playlist"),
            confirm = tr("Create"),
            onDismiss = { newPlaylistFor = null },
            onConfirm = { name ->
                savePlaylists(playlistsMap + (name to ((playlistsMap[name] ?: emptyList()) + uris).distinct()))
                newPlaylistFor = null
                selected = emptySet()
            }
        )
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(KnxoColors.theme.bgTop, KnxoColors.theme.bgMid, KnxoColors.theme.bgBottom)))
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = OnBg,
            bottomBar = {
                Column {
                    if (nowTitle != null) {
                        MiniPlayer(
                            song = nowSong,
                            title = nowTitle ?: "",
                            artist = nowArtist,
                            playing = nowPlaying,
                            onOpen = { showNowPlaying = true },
                            onPrev = { controller?.seekToPreviousMediaItem() },
                            onToggle = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                            onNext = { controller?.seekToNextMediaItem() }
                        )
                    }
                    NavigationBar(containerColor = KnxoColors.theme.nav, contentColor = OnBg) {
                        listOf(
                            Triple(tr("Video"), Icons.Filled.VideoLibrary, 0),
                            Triple(tr("Music"), Icons.Filled.MusicNote, 1),
                            Triple(tr("Playlist"), Icons.Filled.LibraryMusic, 4),
                            Triple(tr("Browser"), Icons.Filled.Public, 6)
                        ).forEachIndexed { idx, (label, icon, target) ->
                            NavigationBarItem(
                                selected = section == idx,
                                onClick = {
                                    if (section != idx) tab = target
                                    detail = null
                                    selected = emptySet()
                                    searching = false
                                    query = ""
                                },
                                icon = { Icon(icon, label) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blue,
                                    selectedTextColor = Blue,
                                    indicatorColor = BarBg,
                                    unselectedIconColor = Grey,
                                    unselectedTextColor = Grey
                                )
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                if (lastUri != null && tab == 0 && detail == null && selected.isEmpty()) {
                    FloatingActionButton(
                        onClick = {
                            context.playVideos(listOf(Video(0, lastTitle, 0, Uri.parse(lastUri), "", 0)), 0, lastPos)
                        },
                        shape = CircleShape,
                        containerColor = Blue,
                        contentColor = Color.White
                    ) { Icon(Icons.Filled.PlayArrow, contentDescription = tr("Continue")) }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    tab == 6 -> BrowserScreen(browser)
                    !granted -> Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(tr("Permission is needed to show your files"))
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { permLauncher.launch(askPerms) }) { Text(tr("Allow access")) }
                    }
                    detail != null && tab == 0 -> Column(Modifier.fillMaxSize()) {
                        DetailHeader(if (detail == "All videos" || detail == "Recent") tr(detail!!) else detail!!, onBack = { detail = null })
                        val vlist = when (detail) {
                            "All videos" -> videos
                            "Recent" -> recents.mapNotNull { u -> videos.find { it.uri.toString() == u } }
                            else -> videos.filter { it.folder == detail }
                        }
                        VideoList(vlist, env, viewOpts, sorted = detail != "Recent")
                    }
                    detail != null -> {
                        val base: List<Song> = when (tab) {
                            2 -> songs.filter { it.artist == detail }
                            3 -> songs.filter { it.album == detail }
                            else -> (playlistsMap[detail] ?: emptyList()).mapNotNull { u ->
                                songs.find { it.uri.toString() == u }
                            }
                        }
                        val list: List<Song> = if (tab == 4) base else sortSongs(base, viewOpts)
                        Column(Modifier.fillMaxSize()) {
                            DetailHeader(
                                detail!!,
                                onBack = { detail = null },
                                trailing = {
                                    if (tab == 4) {
                                        IconButton(onClick = {
                                            savePlaylists(playlistsMap - detail!!)
                                            detail = null
                                        }) { Icon(Icons.Filled.Delete, tr("Delete playlist")) }
                                    }
                                }
                            )
                            SongList(list, env, onPlay = { playSongs(list, it) }, opts = viewOpts)
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (searching) {
                                TextField(
                                    value = query,
                                    onValueChange = { query = it },
                                    singleLine = true,
                                    placeholder = { Text(tr("Search")) },
                                    shape = RoundedCornerShape(26.dp),
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = CardColor,
                                        unfocusedContainerColor = CardColor,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent
                                    ),
                                    modifier = Modifier.weight(1f).focusRequester(focus)
                                )
                                IconButton(onClick = { searching = false; query = "" }) { Icon(Icons.Filled.Close, tr("Close")) }
                            } else {
                                Text(
                                    when (section) {
                                        0 -> "Knxo Play"
                                        1 -> tr("Music")
                                        else -> tr("Playlist")
                                    },
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f).then(
                                        if (section == 0) {
                                            Modifier.combinedClickable(
                                                onClick = {},
                                                onLongClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    showPrivate = true
                                                }
                                            )
                                        } else {
                                            Modifier
                                        }
                                    )
                                )
                                IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, tr("Search")) }
                                Box {
                                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, tr("Menu")) }
                                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                        DropdownMenuItem(text = { Text(tr("View & sort")) }, onClick = { menuOpen = false; showView = true })
                                        DropdownMenuItem(text = { Text(tr("Network stream")) }, onClick = { menuOpen = false; showStream = true })
                                        DropdownMenuItem(text = { Text(tr("Refresh")) }, onClick = { menuOpen = false; reloadKey++ })
                                        DropdownMenuItem(text = { Text(tr("Equalizer")) }, onClick = { menuOpen = false; openEqualizer() })
                                        DropdownMenuItem(text = { Text(tr("Settings")) }, onClick = { menuOpen = false; showSettings = true })
                                    }
                                }
                            }
                        }
                        val subTabs: List<Int> = when (tab) {
                            1, 2, 3 -> listOf(1, 2, 3)
                            4, 5 -> listOf(4, 5)
                            else -> emptyList()
                        }
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            tabNames.forEachIndexed { i, t ->
                                if (i !in subTabs) return@forEachIndexed
                                val sel = tab == i
                                Text(
                                    t,
                                    color = if (sel) Color.White else Grey,
                                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (sel) Blue else CardColor)
                                        .clickable { tab = i; detail = null; selected = emptySet() }
                                        .padding(horizontal = 20.dp, vertical = 9.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        when {
                            q.isNotEmpty() && tab == 0 ->
                                VideoList(videos.filter { it.title.contains(q, true) }, env, viewOpts)
                            q.isNotEmpty() -> {
                                val found = sortSongs(
                                    songs.filter {
                                        it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
                                    },
                                    viewOpts
                                )
                                SongList(found, env, onPlay = { playSongs(found, it) }, opts = viewOpts)
                            }
                            tab == 0 -> FolderList(
                                videos, loader,
                                opts = viewOpts,
                                header = {
                                    Column {
                                        QuickActions(
                                            onAll = { detail = "All videos" },
                                            onRecent = { detail = "Recent" },
                                            onMusic = { tab = 1; detail = null },
                                            onStream = { showStream = true }
                                        )
                                        ContinueRow(resumeItems, loader) { r ->
                                            context.playVideos(listOf(r.video), 0, r.posMs)
                                        }
                                    }
                                },
                                onPlayAll = { name ->
                                    val l = videos.filter { it.folder == name }
                                    if (l.isNotEmpty()) context.playVideos(l, 0)
                                }
                            ) { detail = it }
                            tab == 1 -> SongList(songsView, env, onPlay = { playSongs(songsView, it) }, opts = viewOpts, header = {
                                if (songs.isNotEmpty()) {
                                    Row(
                                        Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Button(onClick = { playSongs(songsView, 0) }) {
                                            Icon(Icons.Filled.PlayArrow, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(tr("Play all"))
                                        }
                                        OutlinedButton(onClick = { playSongs(songs, Random.nextInt(songs.size), true) }) {
                                            Icon(Icons.Filled.Shuffle, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(tr("Shuffle"))
                                        }
                                    }
                                }
                            })
                            tab == 2 -> GroupList(
                                songs.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() },
                                Icons.Filled.Person
                            ) { detail = it }
                            tab == 3 -> GroupList(
                                songs.groupBy { it.album }.toList().sortedBy { it.first.lowercase() },
                                Icons.Filled.Album
                            ) { detail = it }
                            tab == 4 -> GroupList(
                                playlistsMap.map { (n, uris) -> n to uris.mapNotNull { u -> songs.find { it.uri.toString() == u } } },
                                Icons.Filled.MusicNote,
                                header = {
                                    Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                                        Button(onClick = { newPlaylistFor = emptyList() }) {
                                            Icon(Icons.Filled.Add, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(tr("New playlist"))
                                        }
                                    }
                                }
                            ) { detail = it }
                            else -> {
                                val favSongs = songs.filter { it.uri.toString() in favs }
                                FavoritesList(
                                    videos.filter { it.uri.toString() in favs },
                                    favSongs, env,
                                    onPlaySong = { playSongs(favSongs, it) }
                                )
                            }
                        }
                    }
                }

                if (selected.isNotEmpty()) {
                    SelectionBar(
                        count = selected.size,
                        allFav = selected.all { it in favs },
                        inPlaylist = inPlaylist,
                        hasSongs = selectedSongs().isNotEmpty(),
                        modifier = Modifier.align(Alignment.TopStart),
                        onClose = { selected = emptySet() },
                        onShare = {
                            val vs = selectedVideos()
                            val ss = selectedSongs()
                            val mime = when {
                                vs.isNotEmpty() && ss.isNotEmpty() -> "*/*"
                                vs.isNotEmpty() -> "video/*"
                                else -> "audio/*"
                            }
                            context.shareUris(vs.map { it.uri } + ss.map { it.uri }, mime)
                            selected = emptySet()
                        },
                        onFav = {
                            val all = selected.all { it in favs }
                            favs = if (all) favs - selected else favs + selected
                            lib.saveFavorites(favs)
                            selected = emptySet()
                        },
                        onMove = { startTransfer("move") },
                        onCopy = { startTransfer("copy") },
                        onPrivate = { movePrivate() },
                        onPlayNext = { queueSongs(selectedSongs(), true); selected = emptySet() },
                        onQueue = { queueSongs(selectedSongs(), false); selected = emptySet() },
                        onAddPlaylist = { addToPlaylist(selectedSongs().map { it.uri.toString() }) },
                        onRemoveFromPlaylist = {
                            val name = detail
                            if (name != null) {
                                savePlaylists(playlistsMap + (name to (playlistsMap[name] ?: emptyList()).filter { it !in selected }))
                            }
                            selected = emptySet()
                        }
                    )
                }
            }
        }

        val c = controller
        if (showNowPlaying && c != null) {
            CompositionLocalProvider(LocalContentColor provides OnBg) {
                NowPlayingScreen(
                    c = c,
                    song = nowSong,
                    title = nowTitle ?: "",
                    artist = nowArtist,
                    playing = nowPlaying,
                    onClose = { showNowPlaying = false }
                )
            }
        }
        if (showPrivate) {
            PrivateScreen(
                lib = lib,
                loader = loader,
                onClose = { showPrivate = false },
                onPlay = { list, i ->
                    PrivateGate.skipLock = true
                    context.playVideos(list, i)
                },
                onToast = { toast(it) }
            )
        }
        if (showSettings) {
            SettingsScreen(
                lib = lib,
                onBack = { showSettings = false },
                onTheme = { showTheme = true },
                onShareApp = { showShareApp = true },
                onBackup = { showBackup = true },
                onRestore = { openLauncher.launch(arrayOf("*/*")) },
                onLanguage = { showLang = true }
            )
        }
        if (showTheme) {
            ThemePickerScreen(
                current = Themes.indexOf(KnxoColors.theme).coerceAtLeast(0),
                onBack = { showTheme = false },
                onUse = { i ->
                    KnxoColors.theme = Themes[i]
                    lib.setIntPref("theme", i)
                    showTheme = false
                }
            )
        }
    }
}
