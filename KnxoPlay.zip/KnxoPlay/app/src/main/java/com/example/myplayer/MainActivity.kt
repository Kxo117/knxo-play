package com.example.myplayer

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Blue = Color(0xFF3B82F6)

@Composable
fun KnxoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Color.Black,
            surface = Color.Black,
            surfaceVariant = Color(0xFF1C2230),
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KnxoTheme { App(tick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

private val permission =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

fun Context.playVideos(list: List<Video>, index: Int, pos: Long = 0L) {
    startActivity(
        Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("uris", ArrayList(list.map { it.uri.toString() }))
            .putStringArrayListExtra("titles", ArrayList(list.map { it.title }))
            .putExtra("index", index)
            .putExtra("pos", pos)
    )
}

@Composable
fun App(tick: Int) {
    val context = LocalContext.current
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED)
    }
    var openFolder by remember { mutableStateOf<String?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val loader = remember { ImageLoader.Builder(context).components { add(VideoFrameDecoder.Factory()) }.build() }
    val prefs = remember { context.getSharedPreferences("knxo", Context.MODE_PRIVATE) }
    val lastUri = remember(tick) { prefs.getString("uri", null) }
    val lastTitle = remember(tick) { prefs.getString("title", "") ?: "" }
    val lastPos = remember(tick) { prefs.getLong("pos", 0L) }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(permission) }
    LaunchedEffect(granted, tick) {
        if (granted) videos = withContext(Dispatchers.IO) { loadVideos(context) }
    }
    BackHandler(enabled = openFolder != null) { openFolder = null }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (lastUri != null && openFolder == null) {
                FloatingActionButton(
                    onClick = {
                        context.playVideos(listOf(Video(0, lastTitle, 0, Uri.parse(lastUri), "", 0)), 0, lastPos)
                    },
                    shape = CircleShape,
                    containerColor = Blue,
                    contentColor = Color.White
                ) { Icon(Icons.Filled.PlayArrow, contentDescription = "Continue") }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                !granted -> Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("ቪዲዮዎችን ለማየት ፈቃድ ያስፈልጋል")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { launcher.launch(permission) }) { Text("Allow access") }
                }
                openFolder == null -> FolderList(videos) { openFolder = it }
                else -> FolderVideos(
                    name = openFolder!!,
                    list = videos.filter { it.folder == openFolder },
                    loader = loader,
                    onBack = { openFolder = null }
                )
            }
        }
    }
}

@Composable
fun FolderList(videos: List<Video>, onOpen: (String) -> Unit) {
    val folders = remember(videos) { videos.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() } }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Text(
                "Knxo Play",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 12.dp)
            )
        }
        items(folders, key = { it.first }) { (name, list) ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(name) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(60.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Folder, null, tint = Color(0xFF8FA3C0), modifier = Modifier.size(34.dp)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(name, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (list.size == 1) "1 video" else "${list.size} videos",
                        fontSize = 14.sp,
                        color = Color(0xFF9AA4B2)
                    )
                }
            }
        }
        item { Spacer(Modifier.height(96.dp)) }
    }
}

@Composable
fun FolderVideos(name: String, list: List<Video>, loader: ImageLoader, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text(name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(list.size, key = { list[it].id }) { i ->
                val v = list[i]
                Row(
                    Modifier.fillMaxWidth().clickable { context.playVideos(list, i) }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(128.dp).height(76.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF1C2230))) {
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(v.uri).videoFrameMillis(1000).build(),
                            imageLoader = loader,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Text(
                            formatDuration(v.durationMs),
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(v.title, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        Text(formatSize(v.sizeBytes), fontSize = 13.sp, color = Color(0xFF9AA4B2))
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
