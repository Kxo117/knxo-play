package com.example.myplayer

import androidx.core.content.FileProvider
import java.io.File
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

class Library(context: Context) {
    private val p = context.getSharedPreferences("knxo_lib", Context.MODE_PRIVATE)

    fun favorites(): Set<String> = HashSet(p.getStringSet("fav", emptySet()) ?: emptySet())

    fun recents(): List<String> =
        (p.getString("recent", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun addRecent(uri: String) {
        val list = (listOf(uri) + recents().filter { it != uri }).take(40)
        p.edit().putString("recent", list.joinToString("\n")).apply()
    }

    fun savePos(uri: String, pos: Long) {
        p.edit().putLong("pos:$uri", pos).apply()
    }

    fun getPos(uri: String): Long = p.getLong("pos:$uri", 0L)

    fun intPref(key: String, def: Int): Int = p.getInt("i_$key", def)

    fun setIntPref(key: String, v: Int) {
        p.edit().putInt("i_$key", v).apply()
    }

    fun viewOpts(): ViewOpts = ViewOpts(
        grid = intPref("view_grid", 0) == 1,
        cols = intPref("grid_cols", 2),
        sortKey = intPref("sort_key", 1),
        desc = intPref("sort_desc", 1) == 1,
        showDuration = flag("show_dur", true),
        showSize = flag("show_size", true)
    )

    fun saveViewOpts(o: ViewOpts) {
        setIntPref("view_grid", if (o.grid) 1 else 0)
        setIntPref("grid_cols", o.cols)
        setIntPref("sort_key", o.sortKey)
        setIntPref("sort_desc", if (o.desc) 1 else 0)
        setFlag("show_dur", o.showDuration)
        setFlag("show_size", o.showSize)
    }

    fun strPref(key: String, def: String = ""): String = p.getString("str_$key", def) ?: def

    fun setStrPref(key: String, v: String) {
        p.edit().putString("str_$key", v).apply()
    }

    fun flag(key: String, def: Boolean): Boolean = p.getBoolean("s_$key", def)

    fun setFlag(key: String, v: Boolean) {
        p.edit().putBoolean("s_$key", v).apply()
    }

    fun saveFavorites(s: Set<String>) {
        p.edit().putStringSet("fav", HashSet(s)).apply()
    }

    private fun names(): List<String> =
        (p.getString("pl_names", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun playlists(): Map<String, List<String>> =
        names().associateWith { n -> (p.getString("pl:$n", "") ?: "").split("\n").filter { it.isNotBlank() } }

    fun savePlaylists(m: Map<String, List<String>>) {
        val e = p.edit()
        names().forEach { e.remove("pl:$it") }
        m.forEach { (n, l) -> e.putString("pl:$n", l.joinToString("\n")) }
        e.putString("pl_names", m.keys.joinToString("\n"))
        e.apply()
    }
}

data class MediaRef(val uri: Uri, val fileName: String, val mime: String, val isVideo: Boolean)

fun copyMedia(context: Context, ref: MediaRef, relPath: String): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    val resolver = context.contentResolver
    val collection =
        if (ref.isVideo) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, ref.fileName)
        put(MediaStore.MediaColumns.MIME_TYPE, ref.mime)
        put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val dst: Uri = (try {
        resolver.insert(collection, values)
    } catch (e: Exception) {
        null
    }) ?: return false
    return try {
        resolver.openInputStream(ref.uri)!!.use { input ->
            resolver.openOutputStream(dst)!!.use { out -> input.copyTo(out) }
        }
        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        resolver.update(dst, done, null, null)
        true
    } catch (e: Exception) {
        try {
            resolver.delete(dst, null, null)
        } catch (e2: Exception) {
        }
        false
    }
}

fun Context.shareUris(uris: List<Uri>, mime: String) {
    if (uris.isEmpty()) return
    val intent =
        if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
    intent.type = mime
    val clip = ClipData.newRawUri("", uris[0])
    uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
    intent.clipData = clip
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    startActivity(Intent.createChooser(intent, "Share"))
}

fun Context.shareMedia(uri: Uri, mime: String) = shareUris(listOf(uri), mime)

fun Context.openUrl(url: String) {
    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

fun saveFrame(context: Context, uri: Uri, posMs: Long): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(context, uri)
        val bmp = r.getFrameAtTime(posMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
        if (bmp == null) {
            false
        } else {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "Knxo_${System.currentTimeMillis()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/KnxoPlay")
            }
            val dst = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (dst == null) {
                false
            } else {
                context.contentResolver.openOutputStream(dst)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                true
            }
        }
    } catch (e: Exception) {
        false
    } finally {
        try {
            r.release()
        } catch (e: Exception) {
        }
    }
}

fun prepareApkUri(context: Context): Uri? = try {
    val src = File(context.applicationInfo.sourceDir)
    val dir = File(context.cacheDir, "share").apply { mkdirs() }
    val dst = File(dir, "KnxoPlay.apk")
    src.copyTo(dst, overwrite = true)
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", dst)
} catch (e: Exception) {
    null
}

fun Context.shareApk(uri: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "application/vnd.android.package-archive"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_TEXT, "Knxo Play - a modern video and music player by Kenasa.")
        clipData = ClipData.newRawUri("", uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    startActivity(Intent.createChooser(i, "Share Knxo Play"))
}

fun Context.shareInvite() {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(
            Intent.EXTRA_TEXT,
            "Try Knxo Play - a modern video and music player by Kenasa.\nChannel: https://t.me/Ethiopsiphonn"
        )
    }
    startActivity(Intent.createChooser(i, "Share Knxo Play"))
}

data class ViewOpts(
    val grid: Boolean = false,
    val cols: Int = 2,
    val sortKey: Int = 1,
    val desc: Boolean = true,
    val showDuration: Boolean = true,
    val showSize: Boolean = true
)

fun sortVideos(list: List<Video>, o: ViewOpts): List<Video> {
    val sorted = when (o.sortKey) {
        0 -> list.sortedBy { it.title.lowercase() }
        2 -> list.sortedBy { it.sizeBytes }
        3 -> list.sortedBy { it.durationMs }
        else -> list.sortedBy { it.added }
    }
    return if (o.desc) sorted.reversed() else sorted
}

fun sortFolders(groups: List<Pair<String, List<Video>>>, o: ViewOpts): List<Pair<String, List<Video>>> {
    val sorted = when (o.sortKey) {
        0 -> groups.sortedBy { it.first.lowercase() }
        2 -> groups.sortedBy { g -> g.second.sumOf { it.sizeBytes } }
        3 -> groups.sortedBy { it.second.size }
        else -> groups.sortedBy { g -> g.second.maxOf { it.added } }
    }
    return if (o.desc) sorted.reversed() else sorted
}
