package com.example.myplayer

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

class Library(context: Context) {
    private val p = context.getSharedPreferences("knxo_lib", Context.MODE_PRIVATE)

    fun favorites(): Set<String> = HashSet(p.getStringSet("fav", emptySet()) ?: emptySet())

    fun saveFavorites(s: Set<String>) {
        p.edit().putStringSet("fav", HashSet(s)).apply()
    }

    private fun names(): List<String> =
        (p.getString("pl_names", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun playlists(): Map<String, List<String>> =
        names().associateWith { n -> (p.getString("pl:$n", "") ?: "").split("\n").filter { it.isNotBlank() } }

    fun savePlaylists(m: Map<String, List<String>>) {
        val e = p.edit()
        names().forEach { e.remove("pl:$it") }
        m.forEach { (n, l) -> e.putString("pl:$n", l.joinToString("\n")) }
        e.putString("pl_names", m.keys.joinToString("\n"))
        e.apply()
    }
}

data class MediaRef(val uri: Uri, val fileName: String, val mime: String, val isVideo: Boolean)

fun copyMedia(context: Context, ref: MediaRef, relPath: String): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    val resolver = context.contentResolver
    val collection =
        if (ref.isVideo) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, ref.fileName)
        put(MediaStore.MediaColumns.MIME_TYPE, ref.mime)
        put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val dst: Uri = (try {
        resolver.insert(collection, values)
    } catch (e: Exception) {
        null
    }) ?: return false
    return try {
        resolver.openInputStream(ref.uri)!!.use { input ->
            resolver.openOutputStream(dst)!!.use { out -> input.copyTo(out) }
        }
        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        resolver.update(dst, done, null, null)
        true
    } catch (e: Exception) {
        try {
            resolver.delete(dst, null, null)
        } catch (e2: Exception) {
        }
        false
    }
}

fun Context.shareUris(uris: List<Uri>, mime: String) {
    if (uris.isEmpty()) return
    val intent =
        if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
    intent.type = mime
    val clip = ClipData.newRawUri("", uris[0])
    uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
    intent.clipData = clip
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    startActivity(Intent.createChooser(intent, "Share"))
}

fun Context.shareMedia(uri: Uri, mime: String) = shareUris(listOf(uri), mime)

fun Context.openUrl(url: String) {
    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}
