package com.example.myplayer

import android.app.Activity
import android.content.Context
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.view.WindowManager
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.ImageLoader
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object PrivateGate {
    var skipLock = false
}

fun privateDir(context: Context): File = File(context.filesDir, "private").apply { mkdirs() }

fun listPrivate(context: Context): List<File> =
    (privateDir(context).listFiles() ?: emptyArray<File>()).filter { it.isFile }.sortedByDescending { it.lastModified() }

fun mimeOf(name: String): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "video/mp4"

fun privateVideo(f: File): Video =
    Video(f.absolutePath.hashCode().toLong(), f.name, 0L, Uri.fromFile(f), "Private", f.length(), mimeOf(f.name), "", 0L)

fun copyToPrivate(context: Context, ref: MediaRef): Boolean {
    return try {
        val dir = privateDir(context)
        val base = ref.fileName.substringBeforeLast('.')
        val ext = ref.fileName.substringAfterLast('.', "mp4")
        var dst = File(dir, ref.fileName)
        var i = 1
        while (dst.exists()) {
            dst = File(dir, base + "_" + i + "." + ext)
            i++
        }
        val input = context.contentResolver.openInputStream(ref.uri)
        if (input == null) {
            false
        } else {
            input.use { src -> dst.outputStream().use { out -> src.copyTo(out) } }
            true
        }
    } catch (e: Exception) {
        false
    }
}

private fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

fun hasPin(lib: Library): Boolean = lib.strPref("priv_hash").isNotEmpty()

fun setPin(lib: Library, pin: String) {
    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
    lib.setStrPref("priv_salt", salt)
    lib.setStrPref("priv_hash", sha256(salt + pin))
}

fun checkPin(lib: Library, pin: String): Boolean = sha256(lib.strPref("priv_salt") + pin) == lib.strPref("priv_hash")

fun clearPin(lib: Library) {
    lib.setStrPref("priv_salt", "")
    lib.setStrPref("priv_hash", "")
}

fun promptBiometric(context: Context, onSuccess: () -> Unit, onError: (String) -> Unit) {
    if (Build.VERSION.SDK_INT < 28) {
        onError("Not supported on this phone")
        return
    }
    try {
        val executor = ContextCompat.getMainExecutor(context)
        val prompt = BiometricPrompt.Builder(context)
            .setTitle(tr("Private folder"))
            .setNegativeButton(tr("Cancel"), executor) { _, _ -> }
            .build()
        prompt.authenticate(
            CancellationSignal(),
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    onError(errString?.toString() ?: "")
                }
            }
        )
    } catch (e: Exception) {
        onError(e.message ?: "Error")
    }
}

@Composable
private fun PinPad(
    title: String,
    subtitle: String,
    resetKey: Int,
    onComplete: (String) -> Unit,
    onBack: () -> Unit,
    extra: @Composable () -> Unit = {}
) {
    var pin by remember(resetKey) { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(8.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.Close, tr("Close")) }
        }
        Spacer(Modifier.weight(0.5f))
        Icon(Icons.Filled.Lock, null, tint = Blue, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = Grey, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 28.dp))
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            repeat(4) { i ->
                Box(Modifier.size(16.dp).clip(CircleShape).background(if (i < pin.length) Blue else Card2))
            }
        }
        Spacer(Modifier.height(28.dp))
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "⌫")).forEach { keys ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                keys.forEach { k ->
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(if (k.isEmpty()) androidx.compose.ui.graphics.Color.Transparent else CardColor)
                            .clickable(enabled = k.isNotEmpty()) {
                                if (k == "⌫") {
                                    pin = pin.dropLast(1)
                                } else if (pin.length < 4) {
                                    pin += k
                                    if (pin.length == 4) onComplete(pin)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) { Text(k, fontSize = 26.sp) }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        extra()
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun PrivateRow(v: Video, loader: ImageLoader, onOpen: () -> Unit, onRestore: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(CardColor)
            .clickable(onClick = onOpen)
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VideoThumb(v, loader, Modifier.width(112.dp).height(66.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(formatSize(v.sizeBytes), fontSize = 13.sp, color = Grey)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, tr("Menu"), tint = Grey) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(tr("Restore to gallery")) }, onClick = { menu = false; onRestore() })
                DropdownMenuItem(text = { Text(tr("Delete")) }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
fun PrivateScreen(
    lib: Library,
    loader: ImageLoader,
    onClose: () -> Unit,
    onPlay: (List<Video>, Int) -> Unit,
    onToast: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var unlocked by remember { mutableStateOf(false) }
    var creating by remember { mutableStateOf(!hasPin(lib)) }
    var firstPin by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var padKey by remember { mutableIntStateOf(0) }
    var fails by remember { mutableIntStateOf(0) }
    var lockedUntil by remember { mutableLongStateOf(0L) }
    var files by remember { mutableStateOf(listPrivate(context)) }
    var toDelete by remember { mutableStateOf<File?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var fp by remember { mutableStateOf(lib.flag("priv_fp", false)) }

    DisposableEffect(Unit) {
        val w = (context as? Activity)?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    BackHandler(enabled = true) {
        if (creating && hasPin(lib)) {
            creating = false
            firstPin = null
            message = ""
        } else {
            onClose()
        }
    }

    fun restore(f: File) {
        if (Build.VERSION.SDK_INT < 29) {
            onToast(tr("Restoring needs Android 10 or newer"))
            return
        }
        scope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) {
                val copied = copyMedia(context, MediaRef(Uri.fromFile(f), f.name, mimeOf(f.name), true), "Movies/")
                if (copied) f.delete()
                copied
            }
            busy = false
            files = listPrivate(context)
            onToast(if (ok) tr("Restored to Movies") else tr("Could not restore this video"))
        }
    }

    CompositionLocalProvider(LocalContentColor provides OnBg) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(KnxoColors.theme.bgTop, KnxoColors.theme.bgMid, KnxoColors.theme.bgBottom)))
                .pointerInput(Unit) { detectTapGestures { } }
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            if (creating) {
                PinPad(
                    title = if (firstPin == null) tr("Create a PIN") else tr("Confirm your PIN"),
                    subtitle = if (message.isNotEmpty()) message else tr("Choose 4 digits. If you forget it, the private videos cannot be recovered."),
                    resetKey = padKey,
                    onComplete = { pin ->
                        val first = firstPin
                        if (first == null) {
                            firstPin = pin
                            message = ""
                        } else if (first == pin) {
                            setPin(lib, pin)
                            creating = false
                            unlocked = true
                            firstPin = null
                            message = ""
                        } else {
                            firstPin = null
                            message = tr("PINs did not match. Try again.")
                        }
                        padKey++
                    },
                    onBack = {
                        if (hasPin(lib)) {
                            creating = false
                            firstPin = null
                            message = ""
                        } else {
                            onClose()
                        }
                    }
                )
            } else if (!unlocked) {
                PinPad(
                    title = tr("Enter PIN"),
                    subtitle = if (message.isNotEmpty()) message else tr("Enter your PIN to open the private folder."),
                    resetKey = padKey,
                    onComplete = { pin ->
                        val now = System.currentTimeMillis()
                        if (now < lockedUntil) {
                            message = tr("Too many attempts. Try again in 30 seconds.")
                        } else if (checkPin(lib, pin)) {
                            unlocked = true
                            fails = 0
                            message = ""
                        } else {
                            fails++
                            message = tr("Wrong PIN")
                            if (fails >= 5) {
                                lockedUntil = now + 30_000L
                                fails = 0
                                message = tr("Too many attempts. Try again in 30 seconds.")
                            }
                        }
                        padKey++
                    },
                    onBack = onClose,
                    extra = {
                        if (Build.VERSION.SDK_INT >= 28 && fp) {
                            TextButton(onClick = {
                                promptBiometric(context, { unlocked = true; message = "" }, { err -> onToast(err) })
                            }) { Text(tr("Use fingerprint")) }
                        }
                        TextButton(onClick = { confirmReset = true }) { Text(tr("Forgot PIN?"), color = Grey) }
                    }
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, tr("Close")) }
                        Text(tr("Private folder"), fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, tr("Menu")) }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(
                                    text = { Text(tr("Change PIN")) },
                                    onClick = {
                                        menu = false
                                        creating = true
                                        firstPin = null
                                        message = ""
                                        padKey++
                                    }
                                )
                                if (Build.VERSION.SDK_INT >= 28) {
                                    DropdownMenuItem(
                                        text = { Text(tr("Unlock with fingerprint") + (if (fp) "  ✓" else "")) },
                                        onClick = {
                                            menu = false
                                            fp = !fp
                                            lib.setFlag("priv_fp", fp)
                                        }
                                    )
                                }
                            }
                        }
                    }
                    if (files.isEmpty()) {
                        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                            Text(
                                tr("No private videos yet.\nSelect videos, then use ⋮ → Move to private folder."),
                                color = Grey,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        val vids = files.map { privateVideo(it) }
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(files.size) { i ->
                                PrivateRow(
                                    v = vids[i],
                                    loader = loader,
                                    onOpen = { onPlay(vids, i) },
                                    onRestore = { restore(files[i]) },
                                    onDelete = { toDelete = files[i] }
                                )
                            }
                            item { Spacer(Modifier.height(24.dp)) }
                        }
                    }
                }
            }
        }

        toDelete?.let { f ->
            AlertDialog(
                onDismissRequest = { toDelete = null },
                containerColor = CardColor,
                title = { Text(tr("Delete this video?")) },
                text = { Text(tr("It will be deleted permanently.")) },
                confirmButton = {
                    TextButton(onClick = {
                        f.delete()
                        files = listPrivate(context)
                        toDelete = null
                    }) { Text(tr("Delete")) }
                },
                dismissButton = { TextButton(onClick = { toDelete = null }) { Text(tr("Cancel")) } }
            )
        }
        if (confirmReset) {
            AlertDialog(
                onDismissRequest = { confirmReset = false },
                containerColor = CardColor,
                title = { Text(tr("Reset private folder?")) },
                text = { Text(tr("This permanently deletes the PIN and every video in the private folder.")) },
                confirmButton = {
                    TextButton(onClick = {
                        confirmReset = false
                        scope.launch {
                            busy = true
                            withContext(Dispatchers.IO) {
                                listPrivate(context).forEach { it.delete() }
                                clearPin(lib)
                            }
                            busy = false
                            files = listPrivate(context)
                            creating = true
                            unlocked = false
                            firstPin = null
                            message = ""
                            padKey++
                        }
                    }) { Text(tr("Reset")) }
                },
                dismissButton = { TextButton(onClick = { confirmReset = false }) { Text(tr("Cancel")) } }
            )
        }
        if (busy) WorkingDialog()
    }
}
