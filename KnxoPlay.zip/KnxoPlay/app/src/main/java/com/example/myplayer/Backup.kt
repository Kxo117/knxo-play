package com.example.myplayer

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

class RestoreResult(
    val favs: Set<String>,
    val playlists: Map<String, List<String>>,
    val matched: Int,
    val missing: Int
)

fun buildBackup(
    favs: Set<String>,
    playlists: Map<String, List<String>>,
    videos: List<Video>,
    songs: List<Song>
): String {
    val vByUri = videos.associateBy { it.uri.toString() }
    val sByUri = songs.associateBy { it.uri.toString() }

    fun entry(u: String): JSONObject? {
        val v = vByUri[u]
        if (v != null) {
            return JSONObject().put("k", "v").put("name", v.title).put("size", v.sizeBytes).put("dur", v.durationMs)
        }
        val s = sByUri[u]
        if (s != null) {
            return JSONObject().put("k", "s").put("name", s.fileName).put("title", s.title).put("dur", s.durationMs)
        }
        return null
    }

    val root = JSONObject()
    root.put("app", "KnxoPlay")
    root.put("format", 1)
    root.put("created", System.currentTimeMillis())
    val favArr = JSONArray()
    favs.forEach { u -> entry(u)?.let { favArr.put(it) } }
    root.put("favorites", favArr)
    val pls = JSONObject()
    playlists.forEach { (name, uris) ->
        val arr = JSONArray()
        uris.forEach { u -> entry(u)?.let { arr.put(it) } }
        pls.put(name, arr)
    }
    root.put("playlists", pls)
    return root.toString(2)
}

fun parseBackup(json: String, videos: List<Video>, songs: List<Song>): RestoreResult? {
    try {
        val root = JSONObject(json)
        if (root.optString("app") != "KnxoPlay") return null
        var matched = 0
        var missing = 0

        fun resolve(e: JSONObject): String? {
            val name = e.optString("name")
            val size = e.optLong("size", 0L)
            val dur = e.optLong("dur", 0L)
            val found: String? = if (e.optString("k") == "v") {
                (videos.firstOrNull { it.title == name && it.sizeBytes == size }
                    ?: videos.firstOrNull { it.title == name && abs(it.durationMs - dur) < 1500 }
                    ?: videos.firstOrNull { it.title == name })?.uri?.toString()
            } else {
                (songs.firstOrNull { it.fileName == name && abs(it.durationMs - dur) < 1500 }
                    ?: songs.firstOrNull { it.fileName == name })?.uri?.toString()
            }
            if (found != null) matched++ else missing++
            return found
        }

        val favs = LinkedHashSet<String>()
        val favArr = root.optJSONArray("favorites") ?: JSONArray()
        for (i in 0 until favArr.length()) {
            resolve(favArr.getJSONObject(i))?.let { favs.add(it) }
        }
        val pls = LinkedHashMap<String, List<String>>()
        val plObj = root.optJSONObject("playlists")
        if (plObj != null) {
            val names = plObj.keys()
            while (names.hasNext()) {
                val name = names.next()
                val arr = plObj.getJSONArray(name)
                val l = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    resolve(arr.getJSONObject(i))?.let { l.add(it) }
                }
                pls[name] = l
            }
        }
        return RestoreResult(favs, pls, matched, missing)
    } catch (e: Exception) {
        return null
    }
}

fun prepareBackupUri(context: Context, json: String): Uri? = try {
    val dir = File(context.cacheDir, "share").apply { mkdirs() }
    val f = File(dir, "KnxoPlay-backup.json")
    f.writeText(json)
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
} catch (e: Exception) {
    null
}

fun Context.shareBackupFile(uri: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "application/json"
        putExtra(Intent.EXTRA_STREAM, uri)
        clipData = ClipData.newRawUri("", uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    startActivity(Intent.createChooser(i, "Send backup"))
}
