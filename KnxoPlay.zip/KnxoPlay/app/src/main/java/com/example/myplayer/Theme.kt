package com.example.myplayer

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

class AppTheme(
    val name: String,
    val light: Boolean,
    val bgTop: Color,
    val bgMid: Color,
    val bgBottom: Color,
    val card: Color,
    val card2: Color,
    val accent: Color,
    val grey: Color,
    val onBg: Color,
    val selected: Color,
    val bar: Color,
    val nav: Color
)

const val DEFAULT_THEME = 8

val Themes: List<AppTheme> = listOf(
    AppTheme(
        "Light", true,
        Color(0xFFF4F6FA), Color(0xFFF9FAFC), Color(0xFFFFFFFF),
        Color(0xFFE8EDF5), Color(0xFFD5DCE8), Color(0xFF2563EB), Color(0xFF5B6575),
        Color(0xFF111827), Color(0xFFBFD3F8), Color(0xFFDCE3EE), Color(0xFFE8EDF5)
    ),
    AppTheme(
        "Dark gray", false,
        Color(0xFF2E2E32), Color(0xFF232326), Color(0xFF18181B),
        Color(0xFF303034), Color(0xFF3C3C42), Color(0xFF4F9BFF), Color(0xFFA0A0A8),
        Color(0xFFFFFFFF), Color(0xFF3A4A66), Color(0xFF3A3A40), Color(0xFF1F1F22)
    ),
    AppTheme(
        "Black", false,
        Color(0xFF000000), Color(0xFF000000), Color(0xFF000000),
        Color(0xFF141414), Color(0xFF222222), Color(0xFF3B82F6), Color(0xFF9AA0A6),
        Color(0xFFFFFFFF), Color(0xFF1E2F4F), Color(0xFF1C1C1C), Color(0xFF0A0A0A)
    ),
    AppTheme(
        "Purple", false,
        Color(0xFF3A0F5C), Color(0xFF230A38), Color(0xFF12051E),
        Color(0xFF4A1C73), Color(0xFF5B2A87), Color(0xFFC77DFF), Color(0xFFC2A8DC),
        Color(0xFFFFFFFF), Color(0xFF6A3A9A), Color(0xFF4A1C73), Color(0xFF1B0B2C)
    ),
    AppTheme(
        "Green", false,
        Color(0xFF0B6B53), Color(0xFF064534), Color(0xFF03231B),
        Color(0xFF0E7D61), Color(0xFF15926F), Color(0xFF22D3A0), Color(0xFFA5D6C6),
        Color(0xFFFFFFFF), Color(0xFF14906E), Color(0xFF0E7D61), Color(0xFF04382B)
    ),
    AppTheme(
        "Crimson", false,
        Color(0xFF5C0F37), Color(0xFF3A0A23), Color(0xFF1E0512),
        Color(0xFF7A1649), Color(0xFF8F2058), Color(0xFFFF5C9D), Color(0xFFE2A9C3),
        Color(0xFFFFFFFF), Color(0xFF9C2A63), Color(0xFF7A1649), Color(0xFF2C0A1A)
    ),
    AppTheme(
        "Violet", false,
        Color(0xFF3D2C84), Color(0xFF241A52), Color(0xFF120C2B),
        Color(0xFF4B3A99), Color(0xFF5D4BB0), Color(0xFFA78BFA), Color(0xFFBDB3E6),
        Color(0xFFFFFFFF), Color(0xFF6A58C4), Color(0xFF4B3A99), Color(0xFF1A1240)
    ),
    AppTheme(
        "Ocean", false,
        Color(0xFF0F6A8C), Color(0xFF094560), Color(0xFF042635),
        Color(0xFF14809F), Color(0xFF1C95B8), Color(0xFF38CFF5), Color(0xFFA8D5E6),
        Color(0xFFFFFFFF), Color(0xFF1E9BC0), Color(0xFF14809F), Color(0xFF063447)
    ),
    AppTheme(
        "Blue", false,
        Color(0xFF101A30), Color(0xFF05070C), Color(0xFF000000),
        Color(0xFF141B2B), Color(0xFF1C2638), Color(0xFF3B82F6), Color(0xFF9AA4B2),
        Color(0xFFFFFFFF), Color(0xFF1E3A6B), Color(0xFF16213A), Color(0xFF0B1220)
    )
)

object KnxoColors {
    var theme by mutableStateOf(Themes[DEFAULT_THEME])
}

val Blue: Color get() = KnxoColors.theme.accent
val Grey: Color get() = KnxoColors.theme.grey
val CardColor: Color get() = KnxoColors.theme.card
val Card2: Color get() = KnxoColors.theme.card2
val SelBg: Color get() = KnxoColors.theme.selected
val BarBg: Color get() = KnxoColors.theme.bar
val OnBg: Color get() = KnxoColors.theme.onBg

fun loadTheme(context: Context) {
    val i = Library(context).intPref("theme", DEFAULT_THEME)
    KnxoColors.theme = Themes.getOrElse(i) { Themes[DEFAULT_THEME] }
}
