package com.example.myplayer

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.net.URLEncoder

fun normalizeUrl(input: String): String {
    val t = input.trim()
    if (t.startsWith("http://") || t.startsWith("https://")) return t
    val looksLikeHost = !t.contains(' ') && t.contains('.')
    return if (looksLikeHost) "https://$t" else "https://www.google.com/search?q=" + URLEncoder.encode(t, "UTF-8")
}

fun isMediaUrl(url: String): Boolean {
    val path = (Uri.parse(url).path ?: "").lowercase()
    return listOf(".mp4", ".mkv", ".webm", ".m3u8", ".mpd", ".mov", ".avi", ".mp3", ".m4a", ".aac", ".flac", ".ogg")
        .any { path.endsWith(it) }
}

class BrowserState(context: Context) {
    var address by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var started by mutableStateOf(false)
    var mediaPrompt by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)

    val web: WebView = WebView(context)

    init {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = s.userAgentString.replace("; wv", "")
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val scheme = u.scheme ?: ""
                if (scheme != "http" && scheme != "https") {
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        message = "No app found to open this link"
                    }
                    return true
                }
                if (isMediaUrl(u.toString())) {
                    mediaPrompt = u.toString()
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null) address = url
                progress = 5
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url != null) address = url
                canBack = view?.canGoBack() ?: false
                canForward = view?.canGoForward() ?: false
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                canBack = view?.canGoBack() ?: false
                canForward = view?.canGoForward() ?: false
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress = newProgress
            }
        }
        web.setDownloadListener { url, _, _, mime, _ ->
            val m = mime ?: ""
            if (isMediaUrl(url) || m.startsWith("video") || m.startsWith("audio")) {
                mediaPrompt = url
            } else {
                message = "Downloads are not supported in this browser"
            }
        }
    }

    fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        started = true
        web.loadUrl(normalizeUrl(t))
    }

    fun home() {
        started = false
        address = ""
        progress = 0
    }

    fun clearData() {
        web.clearCache(true)
        web.clearHistory()
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        message = "Browsing data cleared"
    }
}

private class Shortcut(val name: String, val url: String, val letter: String, val color: Color)

private val shortcuts = listOf(
    Shortcut("Google", "https://www.google.com", "G", Color(0xFF4285F4)),
    Shortcut("YouTube", "https://m.youtube.com", "Y", Color(0xFFE53935)),
    Shortcut("Telegram Web", "https://web.telegram.org/k/", "T", Color(0xFF29A9EB)),
    Shortcut("Ethiopsiphonn", "https://t.me/s/Ethiopsiphonn", "E", Color(0xFF8B5CF6)),
    Shortcut("Wikipedia", "https://www.wikipedia.org", "W", Color(0xFF6B7280)),
    Shortcut("Facebook", "https://m.facebook.com", "F", Color(0xFF1877F2))
)

@Composable
private fun StartPage(b: BrowserState) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(tr("Browser"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        shortcuts.chunked(3).forEach { rowItems ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { s ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(CardColor)
                            .clickable { b.go(s.url) }
                            .padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(44.dp).background(s.color, CircleShape), contentAlignment = Alignment.Center) {
                            Text(s.letter, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(s.name, fontSize = 12.sp, maxLines = 1)
                    }
                }
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            tr("Direct video links (mp4, m3u8 ...) can be played in Knxo Play."),
            color = Grey,
            fontSize = 13.sp
        )
    }
}

@Composable
fun BrowserScreen(b: BrowserState) {
    val context = LocalContext.current
    var text by remember(b.address) { mutableStateOf(b.address) }
    var menu by remember { mutableStateOf(false) }

    LaunchedEffect(b.message) {
        val m = b.message
        if (m != null) {
            Toast.makeText(context, tr(m), Toast.LENGTH_SHORT).show()
            b.message = null
        }
    }

    b.mediaPrompt?.let { url ->
        AlertDialog(
            onDismissRequest = { b.mediaPrompt = null },
            containerColor = CardColor,
            title = { Text(tr("Play in Knxo Play?")) },
            text = { Text(tr("This link is a video or audio file. Play it with the Knxo Play player?")) },
            confirmButton = {
                TextButton(onClick = {
                    b.mediaPrompt = null
                    val name = Uri.parse(url).lastPathSegment ?: url
                    context.playVideos(listOf(Video(0, name, 0L, Uri.parse(url), "", 0L)), 0)
                }) { Text(tr("Play")) }
            },
            dismissButton = { TextButton(onClick = { b.mediaPrompt = null }) { Text(tr("Cancel")) } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text(tr("Search or type a link")) },
                shape = RoundedCornerShape(26.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = CardColor,
                    unfocusedContainerColor = CardColor,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { b.go(text) }),
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { if (b.started) b.web.reload() else b.go(text) }) {
                Icon(Icons.Filled.Refresh, tr("Reload"))
            }
        }
        if (b.started && b.progress in 1..99) {
            LinearProgressIndicator(
                progress = { b.progress / 100f },
                modifier = Modifier.fillMaxWidth(),
                color = Blue
            )
        }
        Box(Modifier.weight(1f)) {
            if (b.started) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        (b.web.parent as? ViewGroup)?.removeView(b.web)
                        b.web
                    }
                )
            } else {
                StartPage(b)
            }
        }
        Row(
            Modifier.fillMaxWidth().background(KnxoColors.theme.nav),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { b.web.goBack() }, enabled = b.started && b.canBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back"))
            }
            IconButton(onClick = { b.web.goForward() }, enabled = b.started && b.canForward) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, tr("Forward"))
            }
            IconButton(onClick = { b.home() }) { Icon(Icons.Filled.Home, tr("Home")) }
            IconButton(
                onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, b.address)
                    }
                    context.startActivity(Intent.createChooser(send, tr("Share link")))
                },
                enabled = b.started && b.address.isNotEmpty()
            ) { Icon(Icons.Filled.Share, tr("Share link")) }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, tr("Menu")) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(tr("Open in another browser")) },
                        onClick = {
                            menu = false
                            if (b.address.isNotEmpty()) {
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(b.address)))
                                } catch (e: Exception) {
                                    b.message = "No app found to open this link"
                                }
                            }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("Clear browsing data")) },
                        onClick = {
                            menu = false
                            b.clearData()
                        }
                    )
                }
            }
        }
    }
}
