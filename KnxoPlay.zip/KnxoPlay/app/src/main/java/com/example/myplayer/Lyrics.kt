package com.example.myplayer

import android.content.Context
import java.io.File
import java.security.MessageDigest

class LyricLine(val timeMs: Long, val text: String)

object LyricsStore {
    private fun key(song: Song): String {
        val raw = "${song.fileName}|${song.durationMs / 1000}"
        return MessageDigest.getInstance("SHA-1").digest(raw.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    private fun file(context: Context, song: Song): File {
        val dir = File(context.filesDir, "lyrics").apply { mkdirs() }
        return File(dir, key(song) + ".txt")
    }

    fun load(context: Context, song: Song): String? {
        val f = file(context, song)
        return if (f.exists()) f.readText() else null
    }

    fun save(context: Context, song: Song, text: String) {
        file(context, song).writeText(text)
    }

    fun delete(context: Context, song: Song) {
        file(context, song).delete()
    }
}

private val lrcTag = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

fun parseLrc(text: String): List<LyricLine> {
    val out = ArrayList<LyricLine>()
    for (raw in text.lines()) {
        val tags = lrcTag.findAll(raw).toList()
        if (tags.isEmpty()) continue
        val body = raw.substring(tags.last().range.last + 1).trim()
        for (m in tags) {
            val min = m.groupValues[1].toLong()
            val sec = m.groupValues[2].toLong()
            val fracStr = m.groupValues[3]
            val frac = when (fracStr.length) {
                0 -> 0L
                1 -> fracStr.toLong() * 100
                2 -> fracStr.toLong() * 10
                else -> fracStr.toLong()
            }
            out.add(LyricLine(min * 60_000 + sec * 1000 + frac, body))
        }
    }
    return out.sortedBy { it.timeMs }
}
