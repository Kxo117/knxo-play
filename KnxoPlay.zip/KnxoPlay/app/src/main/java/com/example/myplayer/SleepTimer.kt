package com.example.myplayer

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player

object SleepTimer {
    var remainingMs by mutableLongStateOf(0L)
    var endOfTrack by mutableStateOf(false)

    private val handler = Handler(Looper.getMainLooper())
    private var endElapsed = 0L
    private var listener: Player.Listener? = null

    private val tick = object : Runnable {
        override fun run() {
            val p = MusicService.playerRef
            if (p == null) {
                cancel()
                return
            }
            val left = endElapsed - SystemClock.elapsedRealtime()
            if (left <= 0L) {
                p.pause()
                cancel()
                return
            }
            remainingMs = left
            if (left < 10_000L) p.volume = (left / 10_000f).coerceIn(0f, 1f)
            handler.postDelayed(this, 500L)
        }
    }

    fun start(minutes: Int) {
        cancel()
        endElapsed = SystemClock.elapsedRealtime() + minutes * 60_000L
        remainingMs = minutes * 60_000L
        handler.post(tick)
    }

    fun endOfSong() {
        cancel()
        val p = MusicService.playerRef ?: return
        p.pauseAtEndOfMediaItems = true
        endOfTrack = true
        val l = object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) cancel()
            }
        }
        listener = l
        p.addListener(l)
    }

    fun cancel() {
        handler.removeCallbacks(tick)
        val p = MusicService.playerRef
        listener?.let { p?.removeListener(it) }
        listener = null
        if (p != null) {
            p.pauseAtEndOfMediaItems = false
            p.volume = 1f
        }
        endElapsed = 0L
        remainingMs = 0L
        endOfTrack = false
    }
}
